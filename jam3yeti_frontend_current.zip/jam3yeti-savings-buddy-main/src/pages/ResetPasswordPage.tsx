import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import apiClient from '../services/api';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

const ResetPasswordPage: React.FC = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!token) {
      setError('Invalid or missing reset token.');
      toast({
        title: "Error",
        description: "Invalid or missing password reset token.",
        variant: "destructive",
      });
      // Optionally redirect to login or forgot password page
      // navigate('/login');
    }
  }, [token, toast, navigate]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    setMessage(null);

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      toast({
        title: "Error",
        description: "Passwords do not match.",
        variant: "destructive",
      });
      return;
    }
    if (!token) {
        setError('Reset token is missing.');
        toast({
            title: "Error",
            description: "Password reset token is missing. Please request a new link.",
            variant: "destructive",
        });
        return;
    }

    setIsLoading(true);
    try {
      await apiClient.post(`/users/reset-password/${token}`, { password });
      setMessage('Your password has been reset successfully. You can now sign in with your new password.');
      toast({
        title: "Success",
        description: "Password reset successful! Please login with your new password.",
      });
      navigate('/login');
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to reset password. The link may be invalid or expired.';
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Reset Your Password</h1>
          <p className="mt-2 text-sm text-gray-600">
            Enter your new password below.
          </p>
        </div>
        {error && <p className="text-sm text-center text-red-600">{error}</p>}
        {message && <p className="text-sm text-center text-green-600">{message}</p>}
        {token ? (
            <form onSubmit={handleSubmit} className="space-y-6">
            <div>
                <Label htmlFor="password">New Password</Label>
                <Input
                id="password"
                name="password"
                type="password"
                autoComplete="new-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1"
                />
            </div>
            <div>
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input
                id="confirm-password"
                name="confirm-password"
                type="password"
                autoComplete="new-password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1"
                />
            </div>
            <div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Resetting Password...' : 'Reset Password'}
                </Button>
            </div>
            </form>
        ) : (
            <div className="text-center">
                <p className="text-sm text-red-600">This password reset link is invalid or has expired. Please request a new one.</p>
                <Link to="/forgot-password" className="mt-4 inline-block font-medium text-indigo-600 hover:text-indigo-500">
                    Request a new reset link
                </Link>
            </div>
        )}
        <div className="mt-4 text-sm text-center">
          <Link to="/login" className="font-medium text-indigo-600 hover:text-indigo-500">
            Back to Sign in
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ResetPasswordPage;


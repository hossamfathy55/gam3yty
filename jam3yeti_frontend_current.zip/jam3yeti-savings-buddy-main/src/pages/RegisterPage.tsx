import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import apiClient from '../services/api';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

const RegisterPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [confirmPasswordError, setConfirmPasswordError] = useState<string | null>(null);
  const [generalError, setGeneralError] = useState<string | null>(null); // For API errors or other general errors

  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Validation functions
  const validateUsername = (value: string): string | null => {
    if (!value) return 'Username is required.';
    if (value.length < 3 || value.length > 20) return 'Username must be between 3 and 20 characters.';
    if (!/^[a-zA-Z0-9_]+$/.test(value)) return 'Username can only contain alphanumeric characters and underscores.';
    return null;
  };

  const validateEmail = (value: string): string | null => {
    if (!value) return 'Email is required.';
    if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(value)) return 'Invalid email format.';
    return null;
  };

  const validatePassword = (value: string): string | null => {
    if (!value) return 'Password is required.';
    if (value.length < 8) return 'Password must be at least 8 characters long.';
    if (!/(?=.*[A-Za-z])(?=.*\d)/.test(value)) return 'Password must contain at least one letter and one number.';
    return null;
  };

  const validateConfirmPassword = (pass: string, confirmPass: string): string | null => {
    if (!confirmPass) return 'Confirm password is required.';
    if (pass !== confirmPass) return 'Passwords do not match.';
    return null;
  };

  useEffect(() => {
    if (username) setUsernameError(validateUsername(username));
  }, [username]);

  useEffect(() => {
    if (email) setEmailError(validateEmail(email));
  }, [email]);

  useEffect(() => {
    if (password) setPasswordError(validatePassword(password));
    // Also re-validate confirm password if password changes
    if (confirmPassword) setConfirmPasswordError(validateConfirmPassword(password, confirmPassword));
  }, [password]);

  useEffect(() => {
    if (confirmPassword) setConfirmPasswordError(validateConfirmPassword(password, confirmPassword));
  }, [confirmPassword, password]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setGeneralError(null);

    // Perform all validations before submitting
    const uError = validateUsername(username);
    const eError = validateEmail(email);
    const pError = validatePassword(password);
    const cpError = validateConfirmPassword(password, confirmPassword);

    setUsernameError(uError);
    setEmailError(eError);
    setPasswordError(pError);
    setConfirmPasswordError(cpError);

    if (uError || eError || pError || cpError) {
        toast({
            title: "Validation Error",
            description: "Please check the form for errors.",
            variant: "destructive",
        });
      return;
    }

    setIsLoading(true);
    try {
      await apiClient.post('/users/register', { username, email, password });
      toast({
        title: "Success",
        description: "Registration successful! Please login.",
      });
      navigate('/login');
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Registration failed. Please try again.';
      setGeneralError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 py-12">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Create an Account</h1>
          <p className="mt-2 text-sm text-gray-600">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-indigo-600 hover:text-indigo-500">
              Sign in
            </Link>
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              name="username"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className={`mt-1 ${usernameError ? 'border-red-500' : ''}`}
            />
            {usernameError && <p className="text-xs text-red-600 mt-1">{usernameError}</p>}
          </div>
          <div>
            <Label htmlFor="email">Email address</Label>
            <Input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={`mt-1 ${emailError ? 'border-red-500' : ''}`}
            />
            {emailError && <p className="text-xs text-red-600 mt-1">{emailError}</p>}
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              name="password"
              type="password"
              autoComplete="new-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`mt-1 ${passwordError ? 'border-red-500' : ''}`}
            />
            {passwordError && <p className="text-xs text-red-600 mt-1">{passwordError}</p>}
          </div>
          <div>
            <Label htmlFor="confirm-password">Confirm Password</Label>
            <Input
              id="confirm-password"
              name="confirm-password"
              type="password"
              autoComplete="new-password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className={`mt-1 ${confirmPasswordError ? 'border-red-500' : ''}`}
            />
            {confirmPasswordError && <p className="text-xs text-red-600 mt-1">{confirmPasswordError}</p>}
          </div>
          {generalError && <p className="text-sm text-red-600 text-center">{generalError}</p>}
          <div>
            <Button type="submit" className="w-full mt-2" disabled={isLoading || !!usernameError || !!emailError || !!passwordError || !!confirmPasswordError}>
              {isLoading ? 'Registering...' : 'Create Account'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegisterPage;



import React from 'react';
import { useNavigate } from 'react-router-dom';

const NotFoundPage = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 rtl">
      <img 
        src="/images/404.png" 
        alt="404" 
        className="w-64 h-64 mb-6" 
      />
      <h1 className="text-2xl font-bold mb-2 text-jameyeti-secondary">صفحة غير موجودة</h1>
      <p className="text-gray-600 mb-6 text-center">
        الصفحة التي تبحث عنها غير متوفرة أو قد تم حذفها
      </p>
      <button
        onClick={() => navigate('/')}
        className="px-6 py-3 bg-jameyeti-primary text-white rounded-lg font-bold"
      >
        العودة للرئيسية
      </button>
    </div>
  );
};

export default NotFoundPage;

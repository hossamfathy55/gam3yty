import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowRight, Share2, MessageCircle, UserPlus, Check, ChevronRight, ChevronLeft, Edit, Trash2 } from 'lucide-react';
import AppHeader from '../components/layout/AppHeader';
import BottomNavigation from '../components/layout/BottomNavigation';
import GroupProgressBar from '../components/groups/GroupProgressBar';
import { Button } from '@/components/ui/button';
import apiClient from '../services/api';
import { useToast } from "@/components/ui/use-toast";

interface GroupDetails {
  id: string;
  name: string;
  description: string;
  target_amount: number;
  current_amount: number;
  creator_id: string;
  created_at: string;
  // Assuming these might come from backend or need to be handled
  images?: string[]; // Optional: if your backend provides it or you handle image separately
  membersCount?: number; // Optional: or calculate from a members array / separate endpoint
  targetMembersCount?: number; // Optional: if this is a separate field from target_amount logic
  deadline?: string; // Optional
  category?: string; // Optional
  features?: string[]; // Optional
  benefits?: string[]; // Optional
  is_member?: boolean; // To know if the current user is a member
  is_creator?: boolean; // To know if the current user is the creator
  progress?: number; // Added for clarity
}

const GroupDetailsPage = () => {
  const { id: groupId } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [group, setGroup] = useState<GroupDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  const fetchGroupDetails = useCallback(async () => {
    if (!groupId) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiClient.get<GroupDetails>(`/groups/${groupId}`);
      setGroup({
        ...response.data,
        images: response.data.images || [
          `/images/placeholder-group.png`,
          '/images/product-detail-1.png',
          '/images/product-detail-2.png'
        ],
        progress: response.data.target_amount > 0 ? (response.data.current_amount / response.data.target_amount) * 100 : 0,
        membersCount: response.data.membersCount || 0, 
        targetMembersCount: response.data.targetMembersCount || 20, 
        deadline: response.data.deadline || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        category: response.data.category || 'متنوع',
        features: response.data.features || ['منتج عالي الجودة', 'سعر تنافسي'],
        benefits: response.data.benefits || ['توفير كبير', 'شراء جماعي آمن'],
      });
    } catch (err: any) {
      console.error("Failed to fetch group details:", err);
      setError("فشل في تحميل تفاصيل المجموعة. يرجى المحاولة مرة أخرى.");
      toast({
        title: "خطأ في التحميل",
        description: err.response?.data?.message || "فشل في تحميل تفاصيل المجموعة.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [groupId, toast]);

  useEffect(() => {
    fetchGroupDetails();
  }, [fetchGroupDetails]);

  const calculateTimeRemaining = (deadline?: string) => {
    if (!deadline) return 'غير محدد';
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - now.getTime();
    
    if (diffTime <= 0) return 'انتهى الوقت';
    
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (diffDays > 0) {
      return `متبقي ${diffDays} يوم${diffDays > 1 ? '' : ''} و ${diffHours} ساعة`;
    }
    return `متبقي ${diffHours} ساعة`;
  };

  const handleJoinLeaveGroup = async () => {
    if (!group) return;
    const action = group.is_member ? 'leave' : 'join';
    try {
      await apiClient.post(`/groups/${group.id}/${action}`);
      toast({
        title: "نجاح",
        description: group.is_member ? "تمت مغادرة المجموعة بنجاح." : "تم الانضمام للمجموعة بنجاح.",
      });
      fetchGroupDetails(); 
    } catch (err: any) {
      toast({
        title: "خطأ",
        description: err.response?.data?.message || `فشل في ${group.is_member ? 'مغادرة' : 'الانضمام إلى'} المجموعة.`, 
        variant: "destructive",
      });
    }
  };
  
  const handleDeleteGroup = async () => {
    if (!group || !group.is_creator) return;
    if (window.confirm("هل أنت متأكد أنك تريد حذف هذه المجموعة؟ لا يمكن التراجع عن هذا الإجراء.")) {
        try {
            await apiClient.delete(`/groups/${group.id}`);
            toast({
                title: "نجاح",
                description: "تم حذف المجموعة بنجاح.",
            });
            navigate('/'); 
        } catch (err: any) {
            toast({
                title: "خطأ في الحذف",
                description: err.response?.data?.message || "فشل في حذف المجموعة.",
                variant: "destructive",
            });
        }
    }
  };

  if (isLoading) {
    return (
      <div className="pb-20 min-h-screen bg-gray-50 flex justify-center items-center">
        <p>جاري تحميل تفاصيل المجموعة...</p>
      </div>
    );
  }

  if (error || !group) {
    return (
      <div className="pb-20 min-h-screen bg-gray-50 flex flex-col justify-center items-center">
        <AppHeader />
        <p className="text-red-500 mt-10">{error || "لم يتم العثور على المجموعة."}</p>
        <Button onClick={() => navigate('/')} className="mt-4">العودة للرئيسية</Button>
        <BottomNavigation />
      </div>
    );
  }

  const timeRemaining = calculateTimeRemaining(group.deadline);
  const discount = group.target_amount && group.current_amount ? Math.round(((group.target_amount - group.current_amount) / group.target_amount) * 100) : 0;

  const nextImage = () => {
    if (!group.images || group.images.length === 0) return;
    setActiveImageIndex((prev) => (prev + 1) % (group.images?.length || 1));
  };

  const prevImage = () => {
    if (!group.images || group.images.length === 0) return;
    setActiveImageIndex((prev) => (prev - 1 + (group.images?.length || 1)) % (group.images?.length || 1));
  };

  return (
    <div className="pb-20 min-h-screen bg-gray-50">
      <AppHeader />
      
      <div className="bg-white mb-2">
        <div className="relative">
          <div className="relative aspect-square overflow-hidden">
            {group.images && group.images.length > 0 ? (
              <img
                src={group.images[activeImageIndex]}
                alt={group.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                <span className="text-gray-500">لا توجد صورة</span>
              </div>
            )}
            {group.images && group.images.length > 1 && (
              <>
                <button 
                  onClick={prevImage} 
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 p-1.5 rounded-full shadow"
                >
                  <ChevronLeft size={20} />
                </button>
                <button 
                  onClick={nextImage} 
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 p-1.5 rounded-full shadow"
                >
                  <ChevronRight size={20} />
                </button>
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-1">
                  {group.images.map((_, index) => (
                    <span 
                      key={index} 
                      className={`block w-2 h-2 rounded-full cursor-pointer ${
                        index === activeImageIndex ? 'bg-jameyeti-primary' : 'bg-white/70'
                      }`}
                      onClick={() => setActiveImageIndex(index)}
                    ></span>
                  ))}
                </div>
              </>
            )}
          </div>
          <button 
            onClick={() => navigate(-1)} 
            className="absolute top-4 right-4 bg-white/80 p-1.5 rounded-full shadow"
          >
            <ArrowRight size={20} />
          </button>
          <button className="absolute top-4 left-4 bg-white/80 p-1.5 rounded-full shadow">
            <Share2 size={20} />
          </button>
        </div>
      </div>
      
      <div className="bg-white p-4 mb-2 rtl">
        <div>
          <div className="flex justify-between items-start mb-2">
            <h1 className="text-xl font-bold text-jameyeti-secondary">{group.name}</h1>
            {group.category && (
              <span className="bg-jameyeti-primary text-white px-2 py-1 rounded-xl text-xs">
                {group.category}
              </span>
            )}
          </div>
          <div className="flex items-baseline space-x-2 space-x-reverse mb-3">
            <span className="font-bold text-xl text-jameyeti-primary">{group.current_amount} ريال</span>
            {group.target_amount > group.current_amount && (
                <span className="text-gray-500 line-through text-sm">{group.target_amount} ريال</span>
            )}
            {discount > 0 && <span className="text-jameyeti-accent text-xs font-medium">وفر {discount}%</span>}
          </div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium">
              هدف المجموعة: {group.membersCount || 0}/{group.targetMembersCount || 'غير محدد'} عضو
            </span>
            <span className="text-sm text-jameyeti-accent font-medium">{timeRemaining}</span>
          </div>
          <GroupProgressBar 
            current={group.membersCount || 0} 
            goal={group.targetMembersCount || 1} 
            progress={group.progress || 0} 
          />
          <div className="flex justify-between items-center mt-1">
            <span className="text-sm text-gray-600">
              {group.membersCount || 0} من أصل {group.targetMembersCount || 'غير محدد'} عضو
            </span>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-4 mb-2 rtl">
        <h2 className="font-bold text-lg mb-2">الوصف</h2>
        <p className="text-gray-700 text-sm leading-relaxed">
          {group.description}
        </p>
      </div>
      
      {group.features && group.features.length > 0 && (
        <div className="bg-white p-4 mb-2 rtl">
          <h2 className="font-bold text-lg mb-2">المميزات</h2>
          <ul className="text-gray-700 space-y-2">
            {group.features.map((feature, index) => (
              <li key={index} className="flex items-center text-sm">
                <Check size={16} className="text-jameyeti-primary ml-2 flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {group.benefits && group.benefits.length > 0 && (
        <div className="bg-white p-4 mb-2 rtl">
          <h2 className="font-bold text-lg mb-2">فوائد الشراء الجماعي</h2>
          <ul className="text-gray-700 space-y-2">
            {group.benefits.map((benefit, index) => (
              <li key={index} className="flex items-center text-sm">
                <Check size={16} className="text-jameyeti-accent ml-2 flex-shrink-0" />
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {group.is_creator && (
        <div className="bg-white p-4 mb-2 rtl flex gap-2">
            <Button 
                variant="outline"
                className="flex-grow"
                onClick={() => navigate(`/groups/${group.id}/edit`)} 
            >
                <Edit size={18} className="ml-2" />
                تعديل المجموعة
            </Button>
            <Button 
                variant="destructive"
                className="flex-grow"
                onClick={handleDeleteGroup}
            >
                <Trash2 size={18} className="ml-2" />
                حذف المجموعة
            </Button>
        </div>
      )}
      
      <div className="fixed bottom-16 left-0 right-0 p-4 bg-white border-t border-gray-200 rtl">
        <div className="flex justify-between gap-3">
          <Button 
            variant="outline"
            className="flex-grow"
            onClick={() => navigate('/assistant')}
          >
            <MessageCircle size={18} className="ml-2" />
            استشر المساعد
          </Button>
          
          {!group.is_creator && (
            <Button 
              className={`flex-grow ${group.is_member ? 'bg-jameyeti-accent hover:bg-jameyeti-accent/90' : 'bg-jameyeti-primary hover:bg-jameyeti-primary/90'}`}
              onClick={handleJoinLeaveGroup}
            >
              {group.is_member ? (
                <>
                  <Check size={18} className="ml-2" />
                  تم الانضمام (مغادرة)
                </>
              ) : (
                <>
                  <UserPlus size={18} className="ml-2" />
                  انضم للمجموعة
                </>
              )}
            </Button>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
};

export default GroupDetailsPage;



import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Bell, CheckCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  isRead: boolean;
  type: 'success' | 'info' | 'warning';
  link?: string;
}

const NotificationsPage = () => {
  const navigate = useNavigate();
  
  // بيانات مثال للإشعارات
  const notifications: Notification[] = [
    {
      id: '1',
      title: 'مبروك! اكتملت المجموعة',
      message: 'اكتملت مجموعة شراء زيت الزيتون البكر وسيتم توصيل الطلب خلال يومين.',
      time: '2025-05-05T10:30:00',
      isRead: false,
      type: 'success',
      link: '/group/olive-oil'
    },
    {
      id: '2',
      title: 'تذكير بالمجموعة',
      message: 'باقي 3 أيام على اكتمال مجموعة الأرز البسمتي، شارك الرابط مع أصدقائك.',
      time: '2025-05-04T14:15:00',
      isRead: false,
      type: 'info',
      link: '/group/rice'
    },
    {
      id: '3',
      title: 'عرض خاص لك',
      message: 'خصم 15% إضافي على مجموعة شراء السكر الأبيض لمدة 24 ساعة فقط!',
      time: '2025-05-03T09:45:00',
      isRead: true,
      type: 'info',
      link: '/group/sugar'
    },
    {
      id: '4',
      title: 'تم توصيل طلبك',
      message: 'تم توصيل طلبك من مجموعة شراء الزيت بنجاح. نتمنى لك تجربة ممتعة!',
      time: '2025-05-01T16:20:00',
      isRead: true,
      type: 'success'
    },
    {
      id: '5',
      title: 'مجموعات جديدة متاحة',
      message: 'تم إضافة 3 مجموعات شراء جديدة لمنتجات قد تهمك. تصفحها الآن!',
      time: '2025-04-29T11:10:00',
      isRead: true,
      type: 'info',
      link: '/browse'
    }
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return 'اليوم';
    } else if (diffDays === 1) {
      return 'البارحة';
    } else if (diffDays < 7) {
      return `قبل ${diffDays} أيام`;
    } else {
      // تنسيق التاريخ بالعربية
      return date.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    }
  };

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'success':
        return <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center"><CheckCheck size={20} className="text-green-600" /></div>;
      case 'warning':
        return <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center"><Bell size={20} className="text-amber-600" /></div>;
      case 'info':
      default:
        return <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center"><Bell size={20} className="text-blue-600" /></div>;
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen bg-gray-50 pb-20 rtl">
      {/* رأس الصفحة */}
      <header className="bg-white p-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center">
          <button onClick={() => navigate(-1)} className="p-1">
            <ArrowRight size={24} />
          </button>
          <h1 className="text-xl font-bold mr-2">الإشعارات</h1>
        </div>
        {unreadCount > 0 && (
          <Button variant="ghost" size="sm" className="text-jameyeti-primary">
            تعيين الكل كمقروء
          </Button>
        )}
      </header>

      {/* قائمة الإشعارات */}
      <div className="p-4">
        {notifications.length > 0 ? (
          <div className="space-y-3">
            {notifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`bg-white rounded-lg p-4 border shadow-sm ${!notification.isRead ? 'border-jameyeti-primary/20 bg-jameyeti-primary/5' : 'border-gray-100'}`}
                onClick={() => notification.link && navigate(notification.link)}
              >
                <div className="flex">
                  <div className="ml-3">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className={`font-bold ${!notification.isRead ? 'text-jameyeti-secondary' : 'text-gray-800'}`}>
                        {notification.title}
                      </h3>
                      <span className="text-xs text-gray-500">{formatDate(notification.time)}</span>
                    </div>
                    <p className="text-gray-600 text-sm mt-1">{notification.message}</p>
                    
                    {notification.link && (
                      <div className="mt-2">
                        <button className="text-jameyeti-primary text-sm font-medium">
                          عرض التفاصيل
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                {!notification.isRead && (
                  <div className="absolute top-3 left-3 w-2 h-2 bg-jameyeti-primary rounded-full"></div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Bell size={48} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-600">لا توجد إشعارات</h3>
            <p className="text-gray-500 text-sm mt-2">سنعلمك عندما يكون هناك تحديثات جديدة</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;

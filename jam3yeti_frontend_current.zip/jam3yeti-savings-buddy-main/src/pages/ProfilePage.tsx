import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import apiClient from '../services/api';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { Settings, ShoppingBag, Heart, HelpCircle, LogOut, UserCircle, Edit3, KeyRound } from 'lucide-react';
import BottomNavigation from '../components/layout/BottomNavigation';
import LogoutButton from '../components/auth/LogoutButton'; // Import the LogoutButton

interface UserProfile {
  id: string;
  username: string;
  email: string;
  // Add other fields as needed from your backend response
}

const ProfilePage = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  // States for editing profile
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editedUsername, setEditedUsername] = useState('');
  const [editedEmail, setEditedEmail] = useState('');

  // States for changing password
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');


  useEffect(() => {
    const fetchUserProfile = async () => {
      setIsLoading(true);
      try {
        const response = await apiClient.get<UserProfile>("/users/profile");
        setUser(response.data);
        setEditedUsername(response.data.username);
        setEditedEmail(response.data.email);
      } catch (err: any) {
        setError(err.response?.data?.message || "Failed to fetch profile. Please try again.");
        toast({
          title: "Error fetching profile",
          description: err.response?.data?.message || "Failed to fetch profile. Please try again.",
          variant: "destructive",
        });
        if (err.response?.status === 401) {
            navigate("/login");
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserProfile();
  }, [navigate, toast]);

  const handleUpdateProfile = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);
    try {
      const response = await apiClient.put<UserProfile>("/users/profile", { 
        username: editedUsername,
        email: editedEmail 
      });
      setUser(response.data);
      toast({ title: "Success", description: "Profile updated successfully!" });
      setIsEditingProfile(false);
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to update profile.");
      toast({ title: "Error", description: err.response?.data?.message || "Failed to update profile.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangePassword = async (event: React.FormEvent) => {
    event.preventDefault();
    if (newPassword !== confirmNewPassword) {
      toast({ title: "Error", description: "New passwords do not match.", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    try {
      await apiClient.put("/users/change-password", { currentPassword, newPassword });
      toast({ title: "Success", description: "Password changed successfully!" });
      setIsChangingPassword(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to change password.");
      toast({ title: "Error", description: err.response?.data?.message || "Failed to change password.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const menuItems = [
    // { icon: ShoppingBag, label: 'طلباتي', route: '/orders' }, // Assuming these are future features
    // { icon: Heart, label: 'الجمعيات المحفوظة', route: '/saved-groups' },
    { icon: Settings, label: 'الإعدادات', action: () => alert("Settings page not implemented yet.") },
    { icon: HelpCircle, label: 'المساعدة', action: () => alert("Help page not implemented yet.") },
  ];

  if (isLoading && !user) {
    return <div className="flex justify-center items-center min-h-screen">Loading profile...</div>;
  }

  if (error && !user) {
    return <div className="flex flex-col justify-center items-center min-h-screen text-red-500">
        <p>{error}</p>
        <Button onClick={() => navigate("/login")} className="mt-4">Go to Login</Button>
    </div>;
  }

  if (!user) {
    return <div className="flex justify-center items-center min-h-screen">User not found.</div>;
  }

  return (
    <div className="pb-20 rtl bg-gray-50 min-h-screen">
      <div className="bg-gradient-to-b from-jameyeti-secondary to-jameyeti-primary text-white p-6 pt-8 pb-16 relative">
        <h1 className="text-xl font-bold mb-6">الملف الشخصي</h1>
        <div className="flex items-center">
          <UserCircle size={80} className="border-4 border-white rounded-full" /> 
          <div className="mr-4">
            <h2 className="text-lg font-bold">{user.username}</h2>
            <p className="text-white text-opacity-80">{user.email}</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-t-3xl -mt-10 p-5">
        {/* Placeholder for stats - to be connected later if needed */}
        {/* <div className="flex justify-around mb-6 bg-white rounded-xl shadow-sm p-4 border border-gray-100">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-jameyeti-primary">0</h3>
            <p className="text-gray-500">طلباتي</p>
          </div>
          <div className="text-center border-r border-l border-gray-200 px-8">
            <h3 className="text-2xl font-bold text-jameyeti-primary">0</h3>
            <p className="text-gray-500">المحفوظات</p>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-bold text-jameyeti-primary">0</h3>
            <p className="text-gray-500">النقاط</p>
          </div>
        </div> */}

        {/* Edit Profile Section */}
        <div className="mb-6 p-4 bg-white rounded-lg border border-gray-100 shadow-sm">
            <div className="flex justify-between items-center mb-3">
                <h3 className="text-md font-semibold">تعديل الملف الشخصي</h3>
                <Button variant="ghost" size="sm" onClick={() => setIsEditingProfile(!isEditingProfile)}>
                    <Edit3 size={18} className="text-jameyeti-primary" />
                </Button>
            </div>
            {isEditingProfile && (
                <form onSubmit={handleUpdateProfile} className="space-y-4 mt-2">
                    <div>
                        <Label htmlFor="edit-username">اسم المستخدم</Label>
                        <Input id="edit-username" value={editedUsername} onChange={(e) => setEditedUsername(e.target.value)} required />
                    </div>
                    <div>
                        <Label htmlFor="edit-email">البريد الإلكتروني</Label>
                        <Input id="edit-email" type="email" value={editedEmail} onChange={(e) => setEditedEmail(e.target.value)} required />
                    </div>
                    <Button type="submit" disabled={isLoading} className="w-full">
                        {isLoading ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                    </Button>
                </form>
            )}
        </div>

        {/* Change Password Section */}
        <div className="mb-6 p-4 bg-white rounded-lg border border-gray-100 shadow-sm">
            <div className="flex justify-between items-center mb-3">
                <h3 className="text-md font-semibold">تغيير كلمة المرور</h3>
                <Button variant="ghost" size="sm" onClick={() => setIsChangingPassword(!isChangingPassword)}>
                    <KeyRound size={18} className="text-jameyeti-primary" />
                </Button>
            </div>
            {isChangingPassword && (
                <form onSubmit={handleChangePassword} className="space-y-4 mt-2">
                    <div>
                        <Label htmlFor="current-password">كلمة المرور الحالية</Label>
                        <Input id="current-password" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
                    </div>
                    <div>
                        <Label htmlFor="new-password">كلمة المرور الجديدة</Label>
                        <Input id="new-password" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
                    </div>
                    <div>
                        <Label htmlFor="confirm-new-password">تأكيد كلمة المرور الجديدة</Label>
                        <Input id="confirm-new-password" type="password" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} required />
                    </div>
                    <Button type="submit" disabled={isLoading} className="w-full">
                        {isLoading ? 'جاري التغيير...' : 'تغيير كلمة المرور'}
                    </Button>
                </form>
            )}
        </div>
        
        <div className="space-y-3">
          {menuItems.map((item, index) => (
            <button 
              key={index}
              onClick={item.action}
              className="w-full flex items-center p-4 bg-white rounded-lg border border-gray-100 shadow-sm text-right"
            >
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center ml-3">
                <item.icon size={20} className="text-jameyeti-secondary" />
              </div>
              <span className="flex-1 font-medium">{item.label}</span>
              <span className="text-jameyeti-primary transform scale-x-[-1]">›</span>
            </button>
          ))}
          
          <LogoutButton />
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
};

export default ProfilePage;


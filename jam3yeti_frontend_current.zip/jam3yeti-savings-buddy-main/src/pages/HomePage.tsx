
import React from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/layout/AppHeader';
import SearchBar from '../components/ui/SearchBar';
import CategorySection from '../components/home/CategorySection';
import ActiveGroupsSection from '../components/groups/ActiveGroupsSection';
import AIAssistantBanner from '../components/home/AIAssistantBanner';
import BottomNavigation from '../components/layout/BottomNavigation';

const HomePage = () => {
  const navigate = useNavigate();
  
  // فتح صفحة تفاصيل المجموعة عند النقر على مجموعة
  const handleGroupClick = (groupId: string) => {
    navigate(`/group/${groupId}`);
  };

  return (
    <div className="pb-20">
      <AppHeader />
      <main>
        <SearchBar />
        <CategorySection />
        <ActiveGroupsSection onGroupClick={handleGroupClick} />
        <AIAssistantBanner />
      </main>
      <BottomNavigation />
    </div>
  );
};

export default HomePage;

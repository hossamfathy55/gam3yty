
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, ChevronDown, Search } from 'lucide-react';
import AppHeader from '../components/layout/AppHeader';
import BottomNavigation from '../components/layout/BottomNavigation';
import GroupCard from '../components/groups/GroupCard';

interface Group {
  id: string;
  title: string;
  image: string;
  currentPrice: number;
  originalPrice: number;
  progress: number;
  membersCount: number;
  targetCount: number;
  deadline: string;
  category: string;
}

const BrowsePage = () => {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState<string>('الكل');
  const [sortBy, setSortBy] = useState<string>('الرائج');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const categories = [
    'الكل', 'زيت', 'أرز', 'سكر', 'منظفات', 'خضار', 'لحوم'
  ];
  
  const sortOptions = [
    'الرائج', 'الأحدث', 'السعر (الأقل)', 'السعر (الأعلى)', 'الخصم'
  ];
  
  // بيانات مثال للمجموعات
  const allGroups: Group[] = [
    {
      id: 'olive-oil',
      title: 'زيت زيتون بكر',
      image: '/images/olive-oil.png',
      currentPrice: 150,
      originalPrice: 180,
      progress: 75,
      membersCount: 15,
      targetCount: 20,
      deadline: '2025-05-13T23:59:59',
      category: 'زيت'
    },
    {
      id: 'rice',
      title: 'أرز بسمتي فاخر',
      image: '/images/rice.png',
      currentPrice: 120,
      originalPrice: 145,
      progress: 60,
      membersCount: 12,
      targetCount: 20,
      deadline: '2025-05-10T23:59:59',
      category: 'أرز'
    },
    {
      id: 'sugar',
      title: 'سكر أبيض ناعم',
      image: '/images/sugar.png',
      currentPrice: 80,
      originalPrice: 95,
      progress: 40,
      membersCount: 8,
      targetCount: 20,
      deadline: '2025-05-15T23:59:59',
      category: 'سكر'
    },
    {
      id: 'flour',
      title: 'طحين فاخر',
      image: '/images/flour.png',
      currentPrice: 65,
      originalPrice: 85,
      progress: 30,
      membersCount: 6,
      targetCount: 20,
      deadline: '2025-05-20T23:59:59',
      category: 'منتجات أخرى'
    },
    {
      id: 'dates',
      title: 'تمر سكري فاخر',
      image: '/images/dates.png',
      currentPrice: 110,
      originalPrice: 135,
      progress: 45,
      membersCount: 9,
      targetCount: 20,
      deadline: '2025-05-18T23:59:59',
      category: 'منتجات أخرى'
    },
    {
      id: 'cleaning-set',
      title: 'طقم منظفات منزلية',
      image: '/images/cleaning.png',
      currentPrice: 95,
      originalPrice: 120,
      progress: 25,
      membersCount: 5,
      targetCount: 20,
      deadline: '2025-05-25T23:59:59',
      category: 'منظفات'
    }
  ];

  // تصفية المجموعات حسب الفئة والبحث
  const filteredGroups = allGroups
    .filter(group => 
      (activeCategory === 'الكل' || group.category === activeCategory) && 
      (searchQuery === '' || group.title.includes(searchQuery))
    );

  return (
    <div className="pb-20 min-h-screen bg-gray-50">
      <AppHeader />
      
      <div className="p-4">
        {/* شريط البحث */}
        <div className="relative mb-4 rtl">
          <input
            type="text"
            placeholder="ابحث عن منتج..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-12 pl-10 pr-4 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-jameyeti-primary"
          />
          <Search 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" 
            size={20} 
          />
        </div>
        
        {/* قسم الفئات */}
        <div className="mb-4 rtl">
          <div className="flex overflow-x-auto pb-2 hide-scrollbar">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`py-2 px-4 mr-2 rounded-full text-sm whitespace-nowrap ${
                  activeCategory === category
                    ? 'bg-jameyeti-primary text-white'
                    : 'bg-white text-gray-700 border border-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        {/* الفرز والتصفية */}
        <div className="flex justify-between items-center mb-4 rtl">
          <div className="text-lg font-bold">المجموعات النشطة</div>
          
          <button
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className="flex items-center text-sm bg-white border border-gray-200 rounded-lg px-3 py-1.5"
          >
            <span>فرز: {sortBy}</span>
            <ChevronDown size={16} className="mr-1" />
          </button>
        </div>
        
        {/* قائمة خيارات الفرز */}
        {isFilterOpen && (
          <div className="bg-white rounded-lg border border-gray-200 mb-4 rtl">
            {sortOptions.map((option) => (
              <button
                key={option}
                onClick={() => {
                  setSortBy(option);
                  setIsFilterOpen(false);
                }}
                className="flex justify-between items-center w-full px-4 py-3 text-right border-b border-gray-100 last:border-0"
              >
                <span>{option}</span>
                {sortBy === option && <Check size={16} className="text-jameyeti-primary" />}
              </button>
            ))}
          </div>
        )}
        
        {/* قائمة المجموعات */}
        <div className="space-y-4 rtl">
          {filteredGroups.length > 0 ? (
            filteredGroups.map((group) => (
              <GroupCard 
                key={group.id} 
                group={group} 
                onClick={() => navigate(`/group/${group.id}`)} 
              />
            ))
          ) : (
            <div className="text-center py-8 bg-white rounded-lg shadow-sm">
              <Search size={36} className="mx-auto text-gray-300 mb-2" />
              <p className="text-gray-600">لا توجد نتائج مطابقة</p>
              <p className="text-sm text-gray-500 mt-1">حاول تغيير معايير البحث</p>
            </div>
          )}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default BrowsePage;

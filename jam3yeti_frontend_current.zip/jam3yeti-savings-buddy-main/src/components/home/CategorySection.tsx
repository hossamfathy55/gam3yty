
import React from 'react';
import CategoryCard from './CategoryCard';

const categories = [
  { name: 'لحوم', icon: '/images/meat.png' },
  { name: 'خضار', icon: '/images/vegetables.png' },
  { name: 'زيت', icon: '/images/oil.png' },
  { name: 'سكر', icon: '/images/sugar.png' },
  { name: 'أرز', icon: '/images/rice.png' },
  { name: 'منظفات', icon: '/images/cleaning.png' },
];

const CategorySection = () => {
  return (
    <section className="px-4 mb-6 rtl">
      <h2 className="text-lg font-bold mb-3">التصنيفات</h2>
      <div className="flex overflow-x-auto pb-2 hide-scrollbar">
        {categories.map((category) => (
          <CategoryCard
            key={category.name}
            name={category.name}
            icon={category.icon}
          />
        ))}
      </div>
    </section>
  );
};

export default CategorySection;


import React from 'react';

interface CategoryCardProps {
  name: string;
  icon: string;
}

const CategoryCard = ({ name, icon }: CategoryCardProps) => {
  return (
    <div className="flex flex-col items-center justify-center w-20 h-20 mr-3 bg-white rounded-xl shadow-sm border border-gray-100 hover:border-jameyeti-primary transition-all animate-scale-in">
      <div className="w-10 h-10 flex items-center justify-center mb-1">
        <img src={icon} alt={name} className="w-full h-full object-contain" />
      </div>
      <p className="text-xs font-medium text-gray-700">{name}</p>
    </div>
  );
};

export default CategoryCard;

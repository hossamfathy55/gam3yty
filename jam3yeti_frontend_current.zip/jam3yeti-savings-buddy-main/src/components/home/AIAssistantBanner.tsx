
import React from 'react';
import { useNavigate } from 'react-router-dom';

const AIAssistantBanner = () => {
  const navigate = useNavigate();
  
  return (
    <div className="bg-gradient-to-r from-jameyeti-primary to-jameyeti-primary-light rounded-xl p-4 mx-4 mb-8 shadow rtl">
      <div className="flex items-center">
        <div className="ml-4">
          <img 
            src="/images/ai-assistant.png" 
            alt="AI Assistant" 
            className="w-16 h-16 object-cover"
          />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-white mb-1">مساعد التوفير الذكي</h3>
          <p className="text-white text-sm opacity-90 mb-2">اسأل مساعدنا عن أفضل العروض وطرق التوفير!</p>
          <button 
            className="bg-white text-jameyeti-primary px-4 py-1 rounded-full text-sm font-medium"
            onClick={() => navigate('/assistant')}
          >
            تحدث معه الآن
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIAssistantBanner;

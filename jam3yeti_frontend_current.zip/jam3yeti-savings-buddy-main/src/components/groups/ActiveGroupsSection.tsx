import React, { useState, useEffect } from 'react';
import apiClient from '../services/api'; // Assuming you have this service configured
import GroupCard from './GroupCard';
import { useToast } from "@/components/ui/use-toast"; // Assuming you use shadcn/ui toast

interface Group {
  id: string;
  name: string;
  description: string;
  target_amount: number;
  current_amount: number;
  creator_id: string;
  created_at: string;
  // Add other relevant fields from your backend Group model
  // For GroupCard, we might need image, membersCount, targetCount, deadline if they exist directly
  // Or we might need to derive/mock them if not directly available from this endpoint
  image?: string; // Optional: if your backend provides it
  membersCount?: number; // Optional: or calculate from a members array
  targetCount?: number; // Optional: might be related to target_amount or a separate field
  deadline?: string; // Optional
}

interface ActiveGroupsProps {
  onGroupClick?: (groupId: string) => void;
}

const ActiveGroupsSection: React.FC<ActiveGroupsProps> = ({ onGroupClick }) => {
  const [groups, setGroups] = useState<Group[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchActiveGroups = async () => {
      setIsLoading(true);
      setError(null);
      try {
        // Adjust the endpoint as per your backend API design for fetching active/all groups
        const response = await apiClient.get<{groups: Group[]}>("/groups"); 
        // Assuming the backend returns an object with a 'groups' array: { groups: [...] }
        // Or if it returns an array directly: const response = await apiClient.get<Group[]>("/groups");
        // setGroups(response.data);
        setGroups(response.data.groups.map(group => ({
          ...group,
          // Mocking image, progress, membersCount, targetCount, deadline for GroupCard if not in backend response
          image: group.image || `/images/placeholder-group.png`, // Provide a placeholder
          progress: group.current_amount && group.target_amount ? (group.current_amount / group.target_amount) * 100 : 0,
          // membersCount, targetCount, deadline might need separate fetching or different logic
          membersCount: group.membersCount || 0, 
          targetCount: group.targetCount || 0, 
          deadline: group.deadline || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // Mock deadline: 7 days from now
          // Adapt title and price for GroupCard
          title: group.name,
          currentPrice: group.current_amount, // Or some other price logic
          originalPrice: group.target_amount, // Or some other price logic
        })));
      } catch (err: any) {
        console.error("Failed to fetch active groups:", err);
        setError("فشل في تحميل الجمعيات النشطة. يرجى المحاولة مرة أخرى.");
        toast({
          title: "خطأ في التحميل",
          description: "فشل في تحميل الجمعيات النشطة. يرجى المحاولة مرة أخرى.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchActiveGroups();
  }, [toast]);

  if (isLoading) {
    return (
      <section className="px-4 mb-6 rtl">
        <h2 className="text-lg font-bold mb-3">الجمعيات النشطة</h2>
        <p>جاري تحميل الجمعيات...</p>
      </section>
    );
  }

  if (error) {
    return (
      <section className="px-4 mb-6 rtl">
        <h2 className="text-lg font-bold mb-3">الجمعيات النشطة</h2>
        <p className="text-red-500">{error}</p>
      </section>
    );
  }

  if (groups.length === 0) {
    return (
      <section className="px-4 mb-6 rtl">
        <h2 className="text-lg font-bold mb-3">الجمعيات النشطة</h2>
        <p>لا توجد جمعيات نشطة حالياً.</p>
      </section>
    );
  }

  return (
    <section className="px-4 mb-6 rtl">
      <h2 className="text-lg font-bold mb-3">الجمعيات النشطة</h2>
      <div className="space-y-4">
        {groups.map((group) => (
          <GroupCard 
            key={group.id} 
            // The GroupCard component expects a specific structure for 'group'
            // We need to map the fetched group data to what GroupCard expects
            group={{
              id: group.id,
              title: group.name, // map 'name' to 'title'
              image: group.image || '/images/placeholder-group.png', // use placeholder if no image
              currentPrice: group.current_amount, // map 'current_amount' to 'currentPrice'
              originalPrice: group.target_amount, // map 'target_amount' to 'originalPrice'
              progress: (group.current_amount / group.target_amount) * 100 || 0,
              membersCount: group.membersCount || 0, // provide default if not available
              targetCount: group.targetCount || 20, // provide default if not available
              deadline: group.deadline || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // Mock deadline
            }}
            onClick={() => onGroupClick?.(group.id)} 
          />
        ))}
      </div>
    </section>
  );
};

export default ActiveGroupsSection;


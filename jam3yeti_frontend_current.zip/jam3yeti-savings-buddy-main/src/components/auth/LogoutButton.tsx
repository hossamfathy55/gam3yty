import React from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '../services/api'; // Assuming api.ts is in src/services
import { Button } from "@/components/ui/button"; // Assuming Button component path
import { useToast } from "@/components/ui/use-toast"; // Assuming useToast hook path

const LogoutButton: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      // Optionally, call a backend endpoint to invalidate the token on the server-side
      // await apiClient.post('/users/logout'); 
      
      localStorage.removeItem('authToken');
      delete apiClient.defaults.headers.common['Authorization'];
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out.",
      });
      navigate('/login'); // Redirect to login page after logout
    } catch (error) {
      console.error('Logout failed:', error);
      toast({
        title: "Logout Failed",
        description: "An error occurred during logout. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Button onClick={handleLogout} variant="outline">
      Logout
    </Button>
  );
};

export default LogoutButton;


import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';

interface ProtectedRouteProps {
  // You can add other props here if needed, like roles for role-based access
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = () => {
  const isAuthenticated = !!localStorage.getItem('authToken'); // Check if token exists

  if (!isAuthenticated) {
    // User not authenticated, redirect to login page
    return <Navigate to="/login" replace />;
  }

  // User is authenticated, render the child routes
  return <Outlet />;
};

export default ProtectedRoute;


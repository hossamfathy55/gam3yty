import axios from 'axios';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default apiClient;

// Example usage (you can expand this with specific service functions):
/*
export const authService = {
  login: (credentials) => apiClient.post('/auth/login', credentials),
  register: (userData) => apiClient.post('/auth/register', userData),
  // ... other auth functions
};

export const groupService = {
  createGroup: (groupData) => apiClient.post('/groups', groupData),
  getGroups: () => apiClient.get('/groups'),
  // ... other group functions
};
*/


import os
import sys
from datetime import timedelta
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify, request # Added request for error handlers
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_mail import Mail # Import Mail
from werkzeug.exceptions import HTTPException

from src.models.user import db
from src.models.group import Group, Membership # Ensure models are imported for db.create_all()
from src.routes.user import user_bp
from src.routes.group import group_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Configuration
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'a_very_strong_default_secret_key_for_dev_only_please_change_this')
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'jam3yeti_db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "another_super_secret_jwt_key_change_it")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=1)
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=30)

# Flask-Mail Configuration (replace with your actual email server details)
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER', 'smtp.mailtrap.io') # Example: 'smtp.googlemail.com'
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', '2525')) # Example: 587 or 465
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'True').lower() in ('true', '1', 't') # Example: True for TLS
app.config['MAIL_USE_SSL'] = os.getenv('MAIL_USE_SSL', 'False').lower() in ('true', '1', 't') # Example: True for SSL (port 465)
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME', 'your_mailtrap_username') # Your email address or username
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD', 'your_mailtrap_password') # Your email password or app password
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@jam3yeti.com') # Default sender address

# Initialize extensions
bcrypt = Bcrypt()
bcrypt.init_app(app)

jwt = JWTManager()
jwt.init_app(app)

db.init_app(app)

mail = Mail() # Initialize Mail
mail.init_app(app) # Configure Mail with the app

CORS(app, resources={r"/api/*": {"origins": "*"}}) # Enable CORS for all /api routes

# Register Blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(group_bp, url_prefix='/api')

# --- Error Handling ---
@app.errorhandler(HTTPException)
def handle_http_exception(e):
    response = e.get_response()
    response.data = jsonify({
        "code": e.code,
        "name": e.name,
        "description": e.description,
    })
    response.content_type = "application/json"
    return response

@app.errorhandler(404)
def page_not_found(e):
    if request.path.startswith('/api/'):
        return jsonify(message="Resource not found", error_code=404), 404
    return jsonify(message="The requested URL was not found on the server.", error_code=404), 404

@app.errorhandler(500)
def internal_server_error(e):
    app.logger.error(f"Server Error: {e}, Path: {request.path}")
    return jsonify(message="An internal server error occurred.", error_code=500), 500

# --- End Error Handling ---

with app.app_context():
    db.create_all()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return jsonify(message="Static folder not configured"), 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            if path.startswith("api/"):
                 return jsonify({"message": "Specified API endpoint not found."}), 404
            return jsonify(message="index.html not found and not an API route"), 404

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)


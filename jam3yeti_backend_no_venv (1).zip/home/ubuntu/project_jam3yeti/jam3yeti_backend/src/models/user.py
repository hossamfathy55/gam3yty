from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_bcrypt import Bcrypt # Import Bcrypt

db = SQLAlchemy()
bcrypt = Bcrypt() # Initialize Bcrypt

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(255), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False) # Adjusted length for bcrypt hash
    full_name = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    last_login_at = db.Column(db.TIMESTAMP, nullable=True)

    # Relationships
    # memberships = db.relationship('Membership', backref='user', lazy='dynamic')
    # created_groups = db.relationship('Group', backref='creator', lazy='dynamic')

    def __repr__(self):
        return f'<User {self.username}>'

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)

# It's common to initialize extensions like Bcrypt in the main application factory
# or a dedicated extensions.py file to avoid circular imports and ensure a single instance.
# For now, initializing it here and in main.py (if needed for app context) should be managed.
# To ensure bcrypt is initialized with the app context, it's better to do:
# In main.py or extensions.py: bcrypt.init_app(app)
# Then import bcrypt from there in other modules.
# However, for model methods, direct use after pip install is also common for bcrypt itself,
# but Flask-Bcrypt typically needs app context for its helper functions if used beyond the model.


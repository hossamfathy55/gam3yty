from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import User # Import User to define relationships

db = SQLAlchemy() # This instance is already created in user.py and main.py, ensure it's the same one.
                    # For simplicity in modular structure, it's often better to initialize db in a central place (e.g. extensions.py)
                    # and import from there. For now, this re-declaration might cause issues if not handled carefully.
                    # Let's assume db is correctly imported/shared from a central point or main app.

class Group(db.Model):
    __tablename__ = 'groups'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    contribution_amount = db.Column(db.Numeric(10, 2), nullable=False)
    payout_frequency = db.Column(db.Enum('weekly', 'monthly', 'bi-monthly', name='payout_frequency_enum'), nullable=False)
    max_members = db.Column(db.Integer, nullable=False)
    current_members_count = db.Column(db.Integer, default=0)
    creator_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    status = db.Column(db.Enum('pending', 'open_for_joining', 'active', 'completed', 'cancelled', name='group_status_enum'), default='pending')
    start_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    creator = db.relationship('User', backref=db.backref('created_groups', lazy=True))
    memberships = db.relationship('Membership', backref='group', lazy='dynamic', cascade="all, delete-orphan")

    def __repr__(self):
        return f'<Group {self.name}>'

class Membership(db.Model):
    __tablename__ = 'memberships'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('groups.id'), nullable=False)
    join_date = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    status = db.Column(db.Enum('pending_approval', 'active', 'left', 'removed', name='membership_status_enum'), default='pending_approval')
    payout_order_preference = db.Column(db.Integer, nullable=True)
    is_admin = db.Column(db.Boolean, default=False) # Indicates if the user is an admin of this specific group

    user = db.relationship('User', backref=db.backref('memberships', lazy='dynamic'))
    # Group relationship is already defined by backref in Group model

    __table_args__ = (db.UniqueConstraint('user_id', 'group_id', name='uq_user_group'),)

    def __repr__(self):
        return f'<Membership user_id={self.user_id} group_id={self.group_id}>'

# It's better to have a single db instance. Assuming db from main.py is used.
# To ensure this, one might pass the `app` object to a function that initializes models
# or use a Flask extension pattern where `db.init_app(app)` is called once.
# For now, we'll rely on the fact that SQLAlchemy can handle multiple model files
# as long as the `db` object is the same instance and tables are created in the app context.


import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import apiClient from '../services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import AppHeader from '../components/layout/AppHeader';
import BottomNavigation from '../components/layout/BottomNavigation';
import { useToast } from "@/components/ui/use-toast";

interface GroupFormData {
  name: string;
  description: string;
  target_amount: string; // Keep as string for form input, convert to number on submit
}

const EditGroupPage = () => {
  const { id: groupId } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [formData, setFormData] = useState<GroupFormData>({
    name: '',
    description: '',
    target_amount: '',
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchGroupData = useCallback(async () => {
    if (!groupId) {
      setError("معرف المجموعة غير موجود.");
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    try {
      const response = await apiClient.get(`/groups/${groupId}`);
      const group = response.data;
      setFormData({
        name: group.name,
        description: group.description,
        target_amount: group.target_amount.toString(),
      });
    } catch (err: any) {
      console.error("Failed to fetch group data for editing:", err);
      setError("فشل في تحميل بيانات المجموعة للتعديل.");
      toast({
        title: "خطأ في التحميل",
        description: err.response?.data?.message || "فشل في تحميل بيانات المجموعة.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [groupId, toast]);

  useEffect(() => {
    fetchGroupData();
  }, [fetchGroupData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!groupId) return;

    const { name, description, target_amount } = formData;
    if (!name.trim() || !description.trim() || !target_amount.trim()) {
        toast({
            title: "خطأ في الإدخال",
            description: "الرجاء ملء جميع الحقول المطلوبة.",
            variant: "destructive",
        });
        return;
    }

    const numericTargetAmount = parseFloat(target_amount);
    if (isNaN(numericTargetAmount) || numericTargetAmount <= 0) {
        toast({
            title: "خطأ في الإدخال",
            description: "الرجاء إدخال مبلغ هدف صحيح وأكبر من صفر.",
            variant: "destructive",
        });
        return;
    }

    setIsSubmitting(true);
    try {
      await apiClient.put(`/groups/${groupId}`, {
        name,
        description,
        target_amount: numericTargetAmount,
      });
      toast({
        title: "نجاح",
        description: "تم تحديث تفاصيل المجموعة بنجاح.",
      });
      navigate(`/groups/${groupId}`); // Navigate back to group details page
    } catch (err: any) {
      console.error("Failed to update group:", err);
      toast({
        title: "خطأ في التحديث",
        description: err.response?.data?.message || "فشل في تحديث المجموعة.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
        <div className="pb-20 min-h-screen bg-gray-50 flex justify-center items-center">
            <AppHeader />
            <p>جاري تحميل بيانات المجموعة للتعديل...</p>
            <BottomNavigation />
        </div>
    );
  }

  if (error) {
    return (
        <div className="pb-20 min-h-screen bg-gray-50 flex flex-col justify-center items-center">
            <AppHeader />
            <p className="text-red-500 mt-10">{error}</p>
            <Button onClick={() => navigate(`/groups/${groupId}`)} className="mt-4">العودة لصفحة المجموعة</Button>
            <BottomNavigation />
        </div>
    );
  }

  return (
    <div className="pb-20 min-h-screen bg-gray-50 rtl">
      <AppHeader title="تعديل المجموعة" />
      <div className="p-4">
        <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow">
          <div>
            <Label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">اسم المجموعة</Label>
            <Input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              required
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-jameyeti-primary focus:border-jameyeti-primary sm:text-sm"
            />
          </div>
          <div>
            <Label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">وصف المجموعة</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
              rows={4}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-jameyeti-primary focus:border-jameyeti-primary sm:text-sm"
            />
          </div>
          <div>
            <Label htmlFor="target_amount" className="block text-sm font-medium text-gray-700 mb-1">المبلغ المستهدف (ريال)</Label>
            <Input
              id="target_amount"
              name="target_amount"
              type="number"
              value={formData.target_amount}
              onChange={handleChange}
              required
              min="0.01"
              step="0.01"
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-jameyeti-primary focus:border-jameyeti-primary sm:text-sm"
            />
          </div>
          
          <div className="flex justify-end space-x-3 space-x-reverse">
            <Button type="button" variant="outline" onClick={() => navigate(`/groups/${groupId}`)} disabled={isSubmitting}>
              إلغاء
            </Button>
            <Button type="submit" className="bg-jameyeti-primary hover:bg-jameyeti-primary/90" disabled={isSubmitting}>
              {isSubmitting ? 'جاري الحفظ...' : 'حفظ التعديلات'}
            </Button>
          </div>
        </form>
      </div>
      <BottomNavigation />
    </div>
  );
};

export default EditGroupPage;


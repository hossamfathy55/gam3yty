import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import apiClient from '../services/api';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

const RegisterPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [confirmPasswordError, setConfirmPasswordError] = useState<string | null>(null);
  const [generalError, setGeneralError] = useState<string | null>(null); 

  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const validateUsername = (value: string): string | null => {
    if (!value) return 'اسم المستخدم مطلوب.';
    if (value.length < 3 || value.length > 20) return 'يجب أن يكون اسم المستخدم بين 3 و 20 حرفًا.';
    if (!/^[a-zA-Z0-9_]+$/.test(value)) return 'يمكن أن يحتوي اسم المستخدم على أحرف أبجدية رقمية وشرطات سفلية فقط.';
    return null;
  };

  const validateEmail = (value: string): string | null => {
    if (!value) return 'البريد الإلكتروني مطلوب.';
    if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(value)) return 'صيغة البريد الإلكتروني غير صالحة.';
    return null;
  };

  const validatePassword = (value: string): string | null => {
    if (!value) return 'كلمة المرور مطلوبة.';
    if (value.length < 8) return 'يجب أن لا تقل كلمة المرور عن 8 أحرف.';
    if (!/(?=.*[A-Za-z])(?=.*\d)/.test(value)) return 'يجب أن تحتوي كلمة المرور على حرف واحد ورقم واحد على الأقل.';
    return null;
  };

  const validateConfirmPassword = (pass: string, confirmPass: string): string | null => {
    if (!confirmPass) return 'تأكيد كلمة المرور مطلوب.';
    if (pass !== confirmPass) return 'كلمات المرور غير متطابقة.';
    return null;
  };

  useEffect(() => {
    if (username) setUsernameError(validateUsername(username));
  }, [username]);

  useEffect(() => {
    if (email) setEmailError(validateEmail(email));
  }, [email]);

  useEffect(() => {
    if (password) setPasswordError(validatePassword(password));
    if (confirmPassword) setConfirmPasswordError(validateConfirmPassword(password, confirmPassword));
  }, [password]);

  useEffect(() => {
    if (confirmPassword) setConfirmPasswordError(validateConfirmPassword(password, confirmPassword));
  }, [confirmPassword, password]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setGeneralError(null);

    const uError = validateUsername(username);
    const eError = validateEmail(email);
    const pError = validatePassword(password);
    const cpError = validateConfirmPassword(password, confirmPassword);

    setUsernameError(uError);
    setEmailError(eError);
    setPasswordError(pError);
    setConfirmPasswordError(cpError);

    if (uError || eError || pError || cpError) {
        toast({
            title: "خطأ في التحقق",
            description: "يرجى التحقق من النموذج بحثًا عن أخطاء.",
            variant: "destructive",
        });
      return;
    }

    setIsLoading(true);
    try {
      await apiClient.post('/users/register', { username, email, password });
      toast({
        title: "نجاح",
        description: "تم التسجيل بنجاح! يرجى تسجيل الدخول.",
      });
      navigate('/login');
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'فشل التسجيل. يرجى المحاولة مرة أخرى.';
      setGeneralError(errorMessage);
      toast({
        title: "خطأ",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-jameyeti-background py-12">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <div className="text-center">
          <img src="/images/logo.png" alt="جمعيتي" className="h-12 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-jameyeti-secondary">إنشاء حساب جديد</h1>
          <p className="mt-2 text-sm text-gray-600">
            هل لديك حساب بالفعل؟{' '}
            <Link to="/login" className="font-medium text-jameyeti-primary hover:text-jameyeti-primary/80">
              تسجيل الدخول
            </Link>
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="username" className="text-jameyeti-text">اسم المستخدم</Label>
            <Input
              id="username"
              name="username"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className={`mt-1 bg-gray-50 border-gray-300 focus:border-jameyeti-primary focus:ring-jameyeti-primary ${usernameError ? 'border-red-500' : ''}`}
            />
            {usernameError && <p className="text-xs text-red-600 mt-1">{usernameError}</p>}
          </div>
          <div>
            <Label htmlFor="email" className="text-jameyeti-text">البريد الإلكتروني</Label>
            <Input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={`mt-1 bg-gray-50 border-gray-300 focus:border-jameyeti-primary focus:ring-jameyeti-primary ${emailError ? 'border-red-500' : ''}`}
            />
            {emailError && <p className="text-xs text-red-600 mt-1">{emailError}</p>}
          </div>
          <div>
            <Label htmlFor="password" className="text-jameyeti-text">كلمة المرور</Label>
            <Input
              id="password"
              name="password"
              type="password"
              autoComplete="new-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`mt-1 bg-gray-50 border-gray-300 focus:border-jameyeti-primary focus:ring-jameyeti-primary ${passwordError ? 'border-red-500' : ''}`}
            />
            {passwordError && <p className="text-xs text-red-600 mt-1">{passwordError}</p>}
          </div>
          <div>
            <Label htmlFor="confirm-password" className="text-jameyeti-text">تأكيد كلمة المرور</Label>
            <Input
              id="confirm-password"
              name="confirm-password"
              type="password"
              autoComplete="new-password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className={`mt-1 bg-gray-50 border-gray-300 focus:border-jameyeti-primary focus:ring-jameyeti-primary ${confirmPasswordError ? 'border-red-500' : ''}`}
            />
            {confirmPasswordError && <p className="text-xs text-red-600 mt-1">{confirmPasswordError}</p>}
          </div>
          {generalError && <p className="text-sm text-red-500 text-center">{generalError}</p>}
          <div>
            <Button type="submit" className="w-full mt-2 bg-jameyeti-primary hover:bg-jameyeti-primary/90 text-white" disabled={isLoading || !!usernameError || !!emailError || !!passwordError || !!confirmPasswordError}>
              {isLoading ? 'جاري التسجيل...' : 'إنشاء حساب'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegisterPage;


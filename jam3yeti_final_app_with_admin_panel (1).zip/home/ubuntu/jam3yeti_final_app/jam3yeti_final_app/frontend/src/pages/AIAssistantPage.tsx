
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Send, User, Bot, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

const AIAssistantPage = () => {
  const navigate = useNavigate();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'مرحبا! أنا مساعد التوفير الذكي، كيف يمكنني مساعدتك اليوم؟',
      sender: 'assistant',
      timestamp: new Date()
    }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // أمثلة مقترحة للمستخدم
  const suggestions = [
    'ما هي أفضل صفقة متاحة حاليا؟',
    'كيف يمكنني توفير المال في مشتريات البقالة؟',
    'أريد نصائح لتوفير مصاريف المنزل',
    'متى أفضل وقت لشراء المنتجات الموسمية؟'
  ];

  const handleSendMessage = () => {
    if (input.trim() === '') return;
    
    // إضافة رسالة المستخدم
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    
    // محاكاة الرد من المساعد (في التطبيق الحقيقي، سيتم استبدال هذا بطلب إلى واجهة برمجة تطبيقات الذكاء الاصطناعي)
    setTimeout(() => {
      let response = '';
      
      if (input.includes('صفقة') || input.includes('عرض')) {
        response = 'أفضل صفقة متاحة حاليًا هي على زيت الزيتون البكر بخصم 20%. هناك أيضًا عرض جيد على الأرز البسمتي.';
      } else if (input.includes('توفير') || input.includes('مصاريف')) {
        response = 'لتوفير المال، أنصحك بالانضمام إلى مجموعات الشراء الجماعي. يمكنك أيضًا شراء المنتجات بكميات كبيرة ومتابعة العروض الأسبوعية.';
      } else if (input.includes('وقت') || input.includes('موسم')) {
        response = 'أفضل وقت لشراء المنتجات الموسمية هو خلال موسمها. مثلاً، الخضروات والفواكه تكون أرخص وأطعم خلال موسم إنتاجها المحلي.';
      } else {
        response = 'شكرًا على سؤالك! يمكنني مساعدتك في العثور على أفضل العروض والنصائح لتوفير المال. هل لديك منتج معين تبحث عنه؟';
      }
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'assistant',
        timestamp: new Date()
      };
      
      setMessages((prev) => [...prev, assistantMessage]);
    }, 1000);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    setTimeout(() => {
      handleSendMessage();
    }, 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  // تنسيق الوقت للعرض
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 rtl">
      {/* رأس الصفحة */}
      <header className="bg-jameyeti-primary p-4 flex items-center text-white">
        <button onClick={() => navigate(-1)} className="p-1">
          <ArrowRight size={24} />
        </button>
        <h1 className="text-xl font-bold mr-2">مساعد التوفير الذكي</h1>
      </header>

      {/* محتوى المحادثة */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.sender === 'user' 
                    ? 'bg-jameyeti-primary text-white rounded-br-none' 
                    : 'bg-white border border-gray-100 rounded-bl-none'
                }`}
              >
                <div className="flex items-center mb-1">
                  {message.sender === 'assistant' && (
                    <Bot size={16} className="ml-1 text-jameyeti-primary" />
                  )}
                  {message.sender === 'user' && (
                    <User size={16} className="ml-1" />
                  )}
                  <span className={`text-xs ${message.sender === 'user' ? 'text-white/80' : 'text-gray-500'}`}>
                    {formatTime(message.timestamp)}
                  </span>
                </div>
                <p className="text-sm whitespace-pre-wrap">{message.text}</p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* اقتراحات للمستخدم */}
      {messages.length < 3 && (
        <div className="px-4 pb-3">
          <p className="text-sm text-gray-500 mb-2">اقتراحات:</p>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(suggestion)}
                className="bg-white text-xs border border-gray-200 rounded-full py-1.5 px-3 text-gray-700 hover:bg-gray-50"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* شريط الإدخال */}
      <div className="bg-white p-3 border-t border-gray-200">
        <div className="flex items-center">
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              ref={inputRef}
              placeholder="اكتب رسالتك هنا..."
              className="w-full py-2 px-4 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-jameyeti-primary"
            />
            {input && (
              <button 
                onClick={() => setInput('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X size={16} />
              </button>
            )}
          </div>
          <Button 
            onClick={handleSendMessage}
            disabled={!input.trim()}
            className="mr-2 rounded-full p-2 h-auto w-auto"
          >
            <Send size={20} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AIAssistantPage;

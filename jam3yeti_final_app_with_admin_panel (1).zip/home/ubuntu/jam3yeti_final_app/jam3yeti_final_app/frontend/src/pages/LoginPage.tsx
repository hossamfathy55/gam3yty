import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import apiClient from '../services/api'; 
import { Button } from "@/components/ui/button"; 
import { Input } from "@/components/ui/input";   
import { Label } from "@/components/ui/label";   
import { useToast } from "@/components/ui/use-toast"; 

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const response = await apiClient.post('/users/login', { email, password });
      const { token } = response.data;
      localStorage.setItem('authToken', token); 
      apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      toast({
        title: "نجاح",
        description: "تم تسجيل الدخول بنجاح!",
      });
      navigate('/'); 
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'فشل تسجيل الدخول. يرجى التحقق من بيانات الاعتماد الخاصة بك والمحاولة مرة أخرى.';
      setError(errorMessage);
      toast({
        title: "خطأ",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-jameyeti-background">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <div className="text-center">
          <img src="/images/logo.png" alt="جمعيتي" className="h-12 mx-auto mb-4" /> 
          <h1 className="text-3xl font-bold text-jameyeti-secondary">تسجيل الدخول إلى حسابك</h1>
          <p className="mt-2 text-sm text-gray-600">
            أو{" "}
            <Link to="/register" className="font-medium text-jameyeti-primary hover:text-jameyeti-primary/80">
              إنشاء حساب جديد
            </Link>
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="email" className="text-jameyeti-text">البريد الإلكتروني</Label>
            <Input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 bg-gray-50 border-gray-300 focus:border-jameyeti-primary focus:ring-jameyeti-primary"
            />
          </div>
          <div>
            <Label htmlFor="password" className="text-jameyeti-text">كلمة المرور</Label>
            <Input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 bg-gray-50 border-gray-300 focus:border-jameyeti-primary focus:ring-jameyeti-primary"
            />
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
          <div className="flex items-center justify-between">
            <div className="text-sm">
              <Link to="/forgot-password" className="font-medium text-jameyeti-primary hover:text-jameyeti-primary/80">
                هل نسيت كلمة المرور؟
              </Link>
            </div>
          </div>
          <div>
            <Button type="submit" className="w-full bg-jameyeti-primary hover:bg-jameyeti-primary/90 text-white" disabled={isLoading}>
              {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;


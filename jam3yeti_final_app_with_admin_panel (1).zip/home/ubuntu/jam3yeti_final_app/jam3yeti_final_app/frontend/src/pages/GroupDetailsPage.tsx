import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowRight, Share2, MessageCircle, UserPlus, Check, ChevronRight, ChevronLeft, Edit, Trash2 } from 'lucide-react';
import AppHeader from '../components/layout/AppHeader';
import BottomNavigation from '../components/layout/BottomNavigation';
import GroupProgressBar from '../components/groups/GroupProgressBar';
import { Button } from '@/components/ui/button';
import apiClient from '../services/api';
import { useToast } from "@/components/ui/use-toast";

interface GroupDetails {
  id: string;
  name: string;
  description: string;
  target_amount: number;
  current_amount: number;
  creator_id: string;
  created_at: string;
  images?: string[]; 
  membersCount?: number; 
  targetMembersCount?: number; 
  deadline?: string; 
  category?: string; 
  features?: string[]; 
  benefits?: string[]; 
  is_member?: boolean; 
  is_creator?: boolean; 
  progress?: number; 
}

const GroupDetailsPage = () => {
  const { id: groupId } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [group, setGroup] = useState<GroupDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  const fetchGroupDetails = useCallback(async () => {
    if (!groupId) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiClient.get<GroupDetails>(`/groups/${groupId}`);
      setGroup({
        ...response.data,
        images: response.data.images && response.data.images.length > 0 ? response.data.images : [
          `/images/placeholder-group.png`,
          // '/images/product-detail-1.png',
          // '/images/product-detail-2.png'
        ],
        progress: response.data.target_amount > 0 ? (response.data.current_amount / response.data.target_amount) * 100 : 0,
        membersCount: response.data.membersCount || 0, 
        targetMembersCount: response.data.targetMembersCount || 20, 
        deadline: response.data.deadline || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        category: response.data.category || 'متنوع',
        features: response.data.features || ['منتج عالي الجودة', 'سعر تنافسي'],
        benefits: response.data.benefits || ['توفير كبير', 'شراء جماعي آمن'],
      });
    } catch (err: any) {
      console.error("Failed to fetch group details:", err);
      setError("فشل في تحميل تفاصيل المجموعة. يرجى المحاولة مرة أخرى.");
      toast({
        title: "خطأ في التحميل",
        description: err.response?.data?.message || "فشل في تحميل تفاصيل المجموعة.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [groupId, toast]);

  useEffect(() => {
    fetchGroupDetails();
  }, [fetchGroupDetails]);

  const calculateTimeRemaining = (deadline?: string) => {
    if (!deadline) return 'غير محدد';
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - now.getTime();
    
    if (diffTime <= 0) return 'انتهى الوقت';
    
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (diffDays > 0) {
      return `متبقي ${diffDays} يوم${diffDays > 1 ? '' : ''} و ${diffHours} ساعة`;
    }
    return `متبقي ${diffHours} ساعة`;
  };

  const handleJoinLeaveGroup = async () => {
    if (!group) return;
    const action = group.is_member ? 'leave' : 'join';
    try {
      await apiClient.post(`/groups/${group.id}/${action}`);
      toast({
        title: "نجاح",
        description: group.is_member ? "تمت مغادرة المجموعة بنجاح." : "تم الانضمام للمجموعة بنجاح.",
      });
      fetchGroupDetails(); 
    } catch (err: any) {
      toast({
        title: "خطأ",
        description: err.response?.data?.message || `فشل في ${group.is_member ? 'مغادرة' : 'الانضمام إلى'} المجموعة.`, 
        variant: "destructive",
      });
    }
  };
  
  const handleDeleteGroup = async () => {
    if (!group || !group.is_creator) return;
    if (window.confirm("هل أنت متأكد أنك تريد حذف هذه المجموعة؟ لا يمكن التراجع عن هذا الإجراء.")) {
        try {
            await apiClient.delete(`/groups/${group.id}`);
            toast({
                title: "نجاح",
                description: "تم حذف المجموعة بنجاح.",
            });
            navigate('/'); 
        } catch (err: any) {
            toast({
                title: "خطأ في الحذف",
                description: err.response?.data?.message || "فشل في حذف المجموعة.",
                variant: "destructive",
            });
        }
    }
  };

  if (isLoading) {
    return (
      <div className="pb-20 min-h-screen bg-jameyeti-background flex justify-center items-center">
        <p className="text-jameyeti-text">جاري تحميل تفاصيل المجموعة...</p>
      </div>
    );
  }

  if (error || !group) {
    return (
      <div className="pb-20 min-h-screen bg-jameyeti-background flex flex-col justify-center items-center">
        <AppHeader />
        <p className="text-red-500 mt-10 text-center px-4">{error || "لم يتم العثور على المجموعة."}</p>
        <Button onClick={() => navigate('/')} className="mt-4 bg-jameyeti-primary hover:bg-jameyeti-primary/90 text-white">العودة للرئيسية</Button>
        <BottomNavigation />
      </div>
    );
  }

  const timeRemaining = calculateTimeRemaining(group.deadline);
  const discount = group.target_amount && group.current_amount ? Math.round(((group.target_amount - group.current_amount) / group.target_amount) * 100) : 0;

  const nextImage = () => {
    if (!group.images || group.images.length === 0) return;
    setActiveImageIndex((prev) => (prev + 1) % (group.images?.length || 1));
  };

  const prevImage = () => {
    if (!group.images || group.images.length === 0) return;
    setActiveImageIndex((prev) => (prev - 1 + (group.images?.length || 1)) % (group.images?.length || 1));
  };

  return (
    <div className="pb-32 bg-jameyeti-background min-h-screen">
      <AppHeader />
      
      <div className="bg-white mb-2 shadow-sm">
        <div className="relative">
          <div className="relative aspect-square overflow-hidden">
            {group.images && group.images.length > 0 ? (
              <img
                src={group.images[activeImageIndex]}
                alt={group.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                <span className="text-gray-500">لا توجد صورة</span>
              </div>
            )}
            {group.images && group.images.length > 1 && (
              <>
                <button 
                  onClick={prevImage} 
                  className="absolute left-3 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white/95 p-2 rounded-full shadow-md transition-colors"
                >
                  <ChevronLeft size={20} className="text-jameyeti-secondary" />
                </button>
                <button 
                  onClick={nextImage} 
                  className="absolute right-3 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white/95 p-2 rounded-full shadow-md transition-colors"
                >
                  <ChevronRight size={20} className="text-jameyeti-secondary" />
                </button>
                <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex space-x-1.5">
                  {group.images.map((_, index) => (
                    <span 
                      key={index} 
                      className={`block w-2 h-2 rounded-full cursor-pointer transition-colors ${
                        index === activeImageIndex ? 'bg-jameyeti-primary' : 'bg-white/70 hover:bg-white/90'
                      }`}
                      onClick={() => setActiveImageIndex(index)}
                    ></span>
                  ))}
                </div>
              </>
            )}
          </div>
          <button 
            onClick={() => navigate(-1)} 
            className="absolute top-4 right-4 bg-white/80 hover:bg-white/95 p-2 rounded-full shadow-md transition-colors"
          >
            <ArrowRight size={20} className="text-jameyeti-secondary" />
          </button>
          <button className="absolute top-4 left-4 bg-white/80 hover:bg-white/95 p-2 rounded-full shadow-md transition-colors">
            <Share2 size={20} className="text-jameyeti-secondary" />
          </button>
        </div>
      </div>
      
      <div className="bg-white p-4 mb-2 shadow-sm rtl">
        <div>
          <div className="flex justify-between items-start mb-2">
            <h1 className="text-2xl font-bold text-jameyeti-secondary">{group.name}</h1>
            {group.category && (
              <span className="bg-jameyeti-primary-light text-jameyeti-primary px-3 py-1 rounded-full text-xs font-medium">
                {group.category}
              </span>
            )}
          </div>
          <div className="flex items-baseline space-x-2 space-x-reverse mb-3">
            <span className="font-bold text-2xl text-jameyeti-primary">{group.current_amount} ريال</span>
            {group.target_amount > group.current_amount && (
                <span className="text-gray-500 line-through text-base">{group.target_amount} ريال</span>
            )}
            {discount > 0 && <span className="text-jameyeti-accent text-sm font-semibold bg-jameyeti-accent-light px-2 py-0.5 rounded-md">وفر {discount}%</span>}
          </div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium text-jameyeti-text">
              هدف المجموعة: {group.membersCount || 0}/{group.targetMembersCount || 'غير محدد'} عضو
            </span>
            <span className="text-sm text-jameyeti-accent font-medium">{timeRemaining}</span>
          </div>
          <GroupProgressBar 
            current={group.membersCount || 0} 
            goal={group.targetMembersCount || 1} 
            progress={group.progress || 0} 
          />
          <div className="flex justify-between items-center mt-1">
            <span className="text-sm text-gray-600">
              {group.membersCount || 0} من أصل {group.targetMembersCount || 'غير محدد'} عضو
            </span>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-4 mb-2 shadow-sm rtl">
        <h2 className="font-bold text-lg mb-2 text-jameyeti-secondary">الوصف</h2>
        <p className="text-jameyeti-text text-sm leading-relaxed">
          {group.description}
        </p>
      </div>
      
      {group.features && group.features.length > 0 && (
        <div className="bg-white p-4 mb-2 shadow-sm rtl">
          <h2 className="font-bold text-lg mb-2 text-jameyeti-secondary">المميزات</h2>
          <ul className="text-jameyeti-text space-y-2">
            {group.features.map((feature, index) => (
              <li key={index} className="flex items-center text-sm">
                <Check size={18} className="text-jameyeti-primary ml-2 flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {group.benefits && group.benefits.length > 0 && (
        <div className="bg-white p-4 mb-2 shadow-sm rtl">
          <h2 className="font-bold text-lg mb-2 text-jameyeti-secondary">فوائد الشراء الجماعي</h2>
          <ul className="text-jameyeti-text space-y-2">
            {group.benefits.map((benefit, index) => (
              <li key={index} className="flex items-center text-sm">
                <Check size={18} className="text-jameyeti-accent ml-2 flex-shrink-0" />
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {group.is_creator && (
        <div className="bg-white p-4 mb-2 shadow-sm rtl flex gap-3">
            <Button 
                variant="outline"
                className="flex-grow border-jameyeti-primary text-jameyeti-primary hover:bg-jameyeti-primary/10 hover:text-jameyeti-primary"
                onClick={() => navigate(`/groups/${group.id}/edit`)} 
            >
                <Edit size={18} className="ml-2" />
                تعديل المجموعة
            </Button>
            <Button 
                variant="destructive"
                className="flex-grow bg-red-500 hover:bg-red-600 text-white"
                onClick={handleDeleteGroup}
            >
                <Trash2 size={18} className="ml-2" />
                حذف المجموعة
            </Button>
        </div>
      )}
      
      {/* Sticky bottom bar for actions - pushed down by pb-32 on main div */}
      <div className="fixed bottom-16 left-0 right-0 p-4 bg-white border-t border-gray-200 rtl shadow-t-lg">
        <div className="flex justify-between gap-3">
          <Button 
            variant="outline"
            className="flex-grow border-jameyeti-secondary text-jameyeti-secondary hover:bg-jameyeti-secondary/10 hover:text-jameyeti-secondary"
            onClick={() => navigate('/assistant')}
          >
            <MessageCircle size={18} className="ml-2" />
            استشر المساعد
          </Button>
          
          {!group.is_creator && (
            <Button 
              className={`flex-grow text-white ${group.is_member ? 'bg-jameyeti-accent hover:bg-jameyeti-accent/90' : 'bg-jameyeti-primary hover:bg-jameyeti-primary/90'}`}
              onClick={handleJoinLeaveGroup}
            >
              {group.is_member ? (
                <>
                  <Check size={18} className="ml-2" />
                  تم الانضمام (مغادرة)
                </>
              ) : (
                <>
                  <UserPlus size={18} className="ml-2" />
                  انضم للمجموعة
                </>
              )}
            </Button>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
};

export default GroupDetailsPage;


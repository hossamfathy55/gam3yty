import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, PlusCircle, Upload, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea'; // Assuming you have Textarea from shadcn
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"; // Assuming Select from shadcn
import { Label } from "@/components/ui/label";
import apiClient from '../services/api'; // Your API client
import { useToast } from "@/components/ui/use-toast";

const CreateGroupPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [images, setImages] = useState<File[]>([]); // Store File objects for upload
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '', // Corresponds to 'title' in previous version, changed to 'name' for backend
    description: '',
    target_amount: '', // Corresponds to 'discountedPrice' or 'originalPrice'
    // category: '', // Category might be handled differently or not directly part of group creation API
    // deadline: '', // Deadline might be handled differently or set by backend
    // For simplicity, let's assume the backend only needs name, description, target_amount for now
    // Add other fields if your backend /groups endpoint expects them
  });

  // const categories = [
  //   'زيت', 'أرز', 'سكر', 'دقيق', 'منظفات', 'خضار', 'لحوم', 'منتجات أخرى'
  // ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // const handleSelectChange = (name: string, value: string) => {
  //   setFormData(prev => ({ ...prev, [name]: value }));
  // };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    if (imagePreviews.length + files.length > 5) {
      toast({
        title: "تحذير",
        description: 'يمكنك تحميل 5 صور كحد أقصى',
        variant: "destructive"
      });
      return;
    }

    const newImageFiles = Array.from(files);
    setImages(prev => [...prev, ...newImageFiles]);

    newImageFiles.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setImagePreviews(prev => [...prev, e.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
    setImages(prev => prev.filter((_,i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!formData.name || !formData.description || !formData.target_amount || images.length === 0) {
      toast({
        title: "خطأ",
        description: 'يرجى إكمال جميع الحقول المطلوبة وتحميل صورة واحدة على الأقل.',
        variant: "destructive"
      });
      setIsLoading(false);
      return;
    }
    
    // Backend expects numbers for amounts
    const groupData = {
        ...formData,
        target_amount: parseFloat(formData.target_amount),
        // current_amount will be 0 by default on backend or handled there
    };

    // At this point, you would typically use FormData to send files and other data
    // However, the current backend for group creation might not support direct image upload yet
    // For now, let's assume the backend /groups POST endpoint takes JSON and image handling is separate or TBD
    // If image upload is part of this endpoint, you'd use FormData:
    // const dataToSubmit = new FormData();
    // dataToSubmit.append('name', groupData.name);
    // dataToSubmit.append('description', groupData.description);
    // dataToSubmit.append('target_amount', groupData.target_amount.toString());
    // images.forEach(imageFile => dataToSubmit.append('images', imageFile));

    try {
      // Adjust endpoint and payload according to your backend API specification
      await apiClient.post('/groups', groupData); 
      toast({
        title: "نجاح",
        description: 'تم إنشاء المجموعة بنجاح!',
      });
      setTimeout(() => navigate('/'), 1500); // Navigate to home or groups list page
    } catch (error: any) {
      console.error("Failed to create group:", error);
      toast({
        title: "فشل إنشاء المجموعة",
        description: error.response?.data?.message || 'حدث خطأ أثناء محاولة إنشاء المجموعة. يرجى المحاولة مرة أخرى.',
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pb-6 bg-gray-50 rtl">
      <header className="bg-white p-4 flex items-center justify-between border-b sticky top-0 z-10">
        <div className="flex items-center">
          <button onClick={() => navigate(-1)} className="p-1">
            <ArrowRight size={24} />
          </button>
          <h1 className="text-xl font-bold mr-2">إنشاء مجموعة جديدة</h1>
        </div>
      </header>

      <div className="p-4">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h2 className="font-bold text-lg mb-1">صور المنتج</h2>
            <p className="text-xs text-gray-500 mb-3">الصورة الأولى ستكون الصورة الرئيسية للمجموعة (اختياري حالياً).</p>
            <div className="grid grid-cols-3 gap-3 mb-3">
              {imagePreviews.map((image, index) => (
                <div key={index} className="relative aspect-square rounded-lg overflow-hidden border">
                  <img src={image} alt={`صورة ${index + 1}`} className="w-full h-full object-cover" />
                  <button 
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute top-1 left-1 bg-white rounded-full p-1 shadow"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
              
              {imagePreviews.length < 5 && (
                <label className="aspect-square rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer bg-gray-50 hover:bg-gray-100">
                  <Upload size={24} className="text-gray-400" />
                  <span className="text-xs text-gray-500 mt-1">أضف صورة</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleImageUpload} 
                    className="hidden" 
                    multiple 
                  />
                </label>
              )}
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h2 className="font-bold text-lg mb-3">معلومات المجموعة</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name" className="block text-gray-700 text-sm font-medium mb-1">اسم المجموعة/المنتج *</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-jameyeti-primary"
                  placeholder="مثال: زيت زيتون الجوف الفاخر"
                  required
                />
              </div>
              
              {/* Category - Assuming it's not part of the direct group creation for now */}
              {/* <div>
                <Label htmlFor="category" className="block text-gray-700 text-sm font-medium mb-1">الفئة *</Label>
                <Select name="category" value={formData.category} onValueChange={(value) => handleSelectChange('category', value)} required>
                  <SelectTrigger className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-jameyeti-primary">
                    <SelectValue placeholder="اختر الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div> */}
              
              <div>
                <Label htmlFor="target_amount" className="block text-gray-700 text-sm font-medium mb-1">السعر الإجمالي المستهدف للمجموعة (ريال) *</Label>
                <Input
                  id="target_amount"
                  type="number"
                  name="target_amount"
                  value={formData.target_amount}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-jameyeti-primary"
                  placeholder="مثال: 1500 (إجمالي قيمة المنتج للعدد المستهدف)"
                  required
                />
              </div>

              {/* Deadline - Assuming it's not part of the direct group creation for now */}
              {/* <div>
                <Label htmlFor="deadline" className="block text-gray-700 text-sm font-medium mb-1">تاريخ انتهاء المجموعة *</Label>
                <Input
                  id="deadline"
                  type="date"
                  name="deadline"
                  value={formData.deadline}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-jameyeti-primary"
                  required
                />
              </div> */}
              
              <div>
                <Label htmlFor="description" className="block text-gray-700 text-sm font-medium mb-1">وصف المجموعة/المنتج *</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows={4}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-jameyeti-primary"
                  placeholder="اكتب وصفًا تفصيليًا للمنتج أو المجموعة..."
                  required
                ></Textarea>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <p className="text-xs text-gray-600 mb-4">
              بالضغط على "إنشاء المجموعة"، أنت توافق على شروط وأحكام تطبيق جمعيتي وسياسة الخصوصية.
            </p>
            <Button 
              type="submit" 
              className="w-full bg-jameyeti-primary hover:bg-jameyeti-primary/90 h-12 text-lg"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  جاري الإنشاء...
                </>
              ) : (
                <>
                  <PlusCircle size={18} className="ml-2" />
                  إنشاء المجموعة
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateGroupPage;


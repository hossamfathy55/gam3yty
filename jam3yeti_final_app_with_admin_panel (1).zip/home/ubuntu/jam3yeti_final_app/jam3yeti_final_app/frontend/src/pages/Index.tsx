
import React from 'react';
import HomePage from './HomePage';

const Index = () => {
  return <HomePage />;
};

export default Index;

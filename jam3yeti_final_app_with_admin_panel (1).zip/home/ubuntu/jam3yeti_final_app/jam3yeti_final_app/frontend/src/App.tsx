import React, { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";

// Lazy load pages
const Index = lazy(() => import("./pages/Index"));
const NotFound = lazy(() => import("./pages/NotFound"));
const GroupDetailsPage = lazy(() => import("./pages/GroupDetailsPage"));
const AIAssistantPage = lazy(() => import("./pages/AIAssistantPage"));
const CreateGroupPage = lazy(() => import("./pages/CreateGroupPage"));
const ProfilePage = lazy(() => import("./pages/ProfilePage"));
const BrowsePage = lazy(() => import("./pages/BrowsePage"));
const NotificationsPage = lazy(() => import("./pages/NotificationsPage"));
const LoginPage = lazy(() => import("./pages/LoginPage"));
const RegisterPage = lazy(() => import("./pages/RegisterPage"));
const ForgotPasswordPage = lazy(() => import("./pages/ForgotPasswordPage"));
const ResetPasswordPage = lazy(() => import("./pages/ResetPasswordPage"));
const EditGroupPage = lazy(() => import("./pages/EditGroupPage"));

const queryClient = new QueryClient();

const PageLayout = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3, ease: "easeInOut" }}
  >
    {children}
  </motion.div>
);

// Fallback component for Suspense
const LoadingFallback = () => (
  <div className="flex justify-center items-center min-h-screen bg-jameyeti-background">
    <p className="text-jameyeti-text text-lg">جاري تحميل الصفحة...</p>
  </div>
);

const AnimatedRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Suspense fallback={<LoadingFallback />}>
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<PageLayout><Index /></PageLayout>} />
          <Route path="/login" element={<PageLayout><LoginPage /></PageLayout>} />
          <Route path="/register" element={<PageLayout><RegisterPage /></PageLayout>} />
          <Route path="/forgot-password" element={<PageLayout><ForgotPasswordPage /></PageLayout>} />
          <Route path="/reset-password" element={<PageLayout><ResetPasswordPage /></PageLayout>} />
          <Route path="/group/:id" element={<PageLayout><GroupDetailsPage /></PageLayout>} />
          <Route path="/groups/:id/edit" element={<PageLayout><EditGroupPage /></PageLayout>} />
          <Route path="/assistant" element={<PageLayout><AIAssistantPage /></PageLayout>} />
          <Route path="/create-group" element={<PageLayout><CreateGroupPage /></PageLayout>} />
          <Route path="/profile" element={<PageLayout><ProfilePage /></PageLayout>} />
          <Route path="/browse" element={<PageLayout><BrowsePage /></PageLayout>} />
          <Route path="/notifications" element={<PageLayout><NotificationsPage /></PageLayout>} />
          <Route path="*" element={<PageLayout><NotFound /></PageLayout>} />
        </Routes>
      </Suspense>
    </AnimatePresence>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AnimatedRoutes />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;



import React from 'react';

interface GroupProgressBarProps {
  current: number;
  goal: number;
  progress?: number; // Add progress as an optional prop
}

const GroupProgressBar = ({ current, goal, progress }: GroupProgressBarProps) => {
  // Use provided progress or calculate it from current/goal
  const percentage = progress !== undefined ? 
    progress : 
    Math.min(Math.round((current / goal) * 100), 100);
  
  return (
    <div className="w-full mt-1">
      <div className="flex justify-between mb-1 text-xs">
        <span>{percentage}%</span>
        <span>{current}/{goal} عضو</span>
      </div>
      <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-full bg-jameyeti-primary rounded-full transition-all duration-500"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default GroupProgressBar;

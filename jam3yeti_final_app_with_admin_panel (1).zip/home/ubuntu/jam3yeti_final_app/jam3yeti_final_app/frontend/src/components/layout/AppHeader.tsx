import React from 'react';
import { Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AppHeader = () => {
  const navigate = useNavigate();
  
  return (
    <header className="flex justify-between items-center p-4 rtl bg-jameyeti-background shadow-sm">
      <div className="flex items-center">
        <img src="/images/logo.png" alt="جمعيتي" className="h-8" />
        <h1 className="text-xl font-bold mr-2 text-jameyeti-secondary">جمعيتي</h1>
      </div>
      <div>
        <button 
          className="relative p-1"
          onClick={() => navigate('/notifications')}
        >
          <Bell size={24} className="text-jameyeti-secondary" />
          <span className="absolute top-0 right-0 bg-jameyeti-accent text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">
            3
          </span>
        </button>
      </div>
    </header>
  );
};

export default AppHeader;


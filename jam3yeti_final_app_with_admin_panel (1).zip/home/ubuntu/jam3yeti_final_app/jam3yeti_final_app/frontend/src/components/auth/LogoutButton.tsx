import React from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '@/services/api'; // Changed to absolute path
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

const LogoutButton: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      // localStorage.removeItem('authToken');
      // delete apiClient.defaults.headers.common['Authorization'];
      // Temporarily comment out API call if it's causing issues during build for path testing
      // await apiClient.post('/users/logout'); 
      
      localStorage.removeItem('authToken');
      // Ensure apiClient is correctly configured before deleting headers
      if (apiClient && apiClient.defaults && apiClient.defaults.headers && apiClient.defaults.headers.common) {
        delete apiClient.defaults.headers.common['Authorization'];
      }
      
      toast({
        title: "تم تسجيل الخروج",
        description: "لقد تم تسجيل خروجك بنجاح.",
      });
      navigate('/login');
    } catch (error) {
      console.error('فشل تسجيل الخروج:', error);
      toast({
        title: "فشل تسجيل الخروج",
        description: "حدث خطأ أثناء تسجيل الخروج. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  };

  return (
    <Button onClick={handleLogout} variant="outline" className="text-jameyeti-text border-jameyeti-accent hover:bg-jameyeti-accent/10 hover:text-jameyeti-accent">
      تسجيل الخروج
    </Button>
  );
};

export default LogoutButton;


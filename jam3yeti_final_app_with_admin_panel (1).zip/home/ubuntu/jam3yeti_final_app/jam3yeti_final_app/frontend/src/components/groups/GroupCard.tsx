
import React from 'react';
import GroupProgressBar from './GroupProgressBar';

interface Group {
  id: string;
  title: string;
  image: string;
  currentPrice: number;
  originalPrice: number;
  progress: number;
  membersCount: number;
  targetCount: number;
  deadline: string;
}

interface GroupCardProps {
  group: Group;
  onClick?: () => void;
}

const GroupCard: React.FC<GroupCardProps> = ({ group, onClick }) => {
  const calculateTimeRemaining = (deadline: string) => {
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - now.getTime();
    
    if (diffTime <= 0) return 'انتهى الوقت';
    
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (diffDays > 0) {
      return `متبقي ${diffDays} يوم${diffDays > 1 ? '' : ''} و ${diffHours} ساعة`;
    }
    return `متبقي ${diffHours} ساعة`;
  };

  const timeRemaining = calculateTimeRemaining(group.deadline);
  const discount = Math.round(((group.originalPrice - group.currentPrice) / group.originalPrice) * 100);

  return (
    <div 
      className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden cursor-pointer hover:shadow-md transition-shadow" 
      onClick={onClick}
    >
      <div className="flex rtl">
        <div className="w-1/3">
          <img src={group.image} alt={group.title} className="w-full h-full object-cover" />
        </div>
        <div className="w-2/3 p-3">
          <h3 className="font-bold text-jameyeti-secondary mb-1">{group.title}</h3>
          
          <div className="flex items-baseline space-x-2 space-x-reverse mb-2">
            <span className="font-bold text-lg text-jameyeti-primary">{group.currentPrice} ريال</span>
            <span className="text-gray-500 line-through text-sm">{group.originalPrice} ريال</span>
            <span className="text-jameyeti-accent text-xs font-medium">وفر {discount}%</span>
          </div>
          
          <GroupProgressBar 
            current={group.membersCount} 
            goal={group.targetCount} 
            progress={group.progress}
          />
          
          <div className="flex justify-between items-center mt-2 text-xs text-gray-600">
            <span>
              {group.membersCount}/{group.targetCount} عضو
            </span>
            <span>{timeRemaining}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupCard;

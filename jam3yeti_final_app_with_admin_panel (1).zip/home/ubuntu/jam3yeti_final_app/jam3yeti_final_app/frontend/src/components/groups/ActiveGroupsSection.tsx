import React, { useState, useEffect } from 'react';
import apiClient from '@/services/api'; // Changed to absolute path
import GroupCard from './GroupCard';
import { useToast } from "@/components/ui/use-toast";

interface Group {
  id: string;
  name: string;
  description: string;
  target_amount: number;
  current_amount: number;
  creator_id: string;
  created_at: string;
  image?: string; 
  membersCount?: number; 
  targetCount?: number; 
  deadline?: string; 
}

interface ActiveGroupsProps {
  onGroupClick?: (groupId: string) => void;
}

const ActiveGroupsSection: React.FC<ActiveGroupsProps> = ({ onGroupClick }) => {
  const [groups, setGroups] = useState<Group[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchActiveGroups = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await apiClient.get<{groups: Group[]}>("/groups"); 
        setGroups(response.data.groups.map(group => ({
          ...group,
          image: group.image || `/images/placeholder-group.png`, 
          progress: group.current_amount && group.target_amount ? (group.current_amount / group.target_amount) * 100 : 0,
          membersCount: group.membersCount || 0, 
          targetCount: group.targetCount || 0, 
          deadline: group.deadline || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), 
          title: group.name,
          currentPrice: group.current_amount, 
          originalPrice: group.target_amount, 
        })));
      } catch (err: any) {
        console.error("Failed to fetch active groups:", err);
        setError("فشل في تحميل الجمعيات النشطة. يرجى المحاولة مرة أخرى.");
        toast({
          title: "خطأ في التحميل",
          description: "فشل في تحميل الجمعيات النشطة. يرجى المحاولة مرة أخرى.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchActiveGroups();
  }, [toast]);

  if (isLoading) {
    return (
      <section className="px-4 mb-6 rtl">
        <h2 className="text-lg font-bold mb-3 text-jameyeti-secondary">الجمعيات النشطة</h2>
        <p className="text-jameyeti-text">جاري تحميل الجمعيات...</p>
      </section>
    );
  }

  if (error) {
    return (
      <section className="px-4 mb-6 rtl">
        <h2 className="text-lg font-bold mb-3 text-jameyeti-secondary">الجمعيات النشطة</h2>
        <p className="text-red-500">{error}</p>
      </section>
    );
  }

  if (groups.length === 0) {
    return (
      <section className="px-4 mb-6 rtl">
        <h2 className="text-lg font-bold mb-3 text-jameyeti-secondary">الجمعيات النشطة</h2>
        <p className="text-jameyeti-text">لا توجد جمعيات نشطة حالياً.</p>
      </section>
    );
  }

  return (
    <section className="mb-6 rtl">
      <h2 className="text-xl font-bold mb-4 text-jameyeti-secondary px-4">الجمعيات النشطة</h2>
      <div className="space-y-4 px-4">
        {groups.map((group) => (
          <GroupCard 
            key={group.id} 
            group={{
              id: group.id,
              title: group.name, 
              image: group.image || '/images/placeholder-group.png', 
              currentPrice: group.current_amount, 
              originalPrice: group.target_amount, 
              progress: (group.current_amount / group.target_amount) * 100 || 0,
              membersCount: group.membersCount || 0, 
              targetCount: group.targetCount || 20, 
              deadline: group.deadline || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), 
            }}
            onClick={() => onGroupClick?.(group.id)} 
          />
        ))}
      </div>
    </section>
  );
};

export default ActiveGroupsSection;


import os
import sys
from datetime import timedelta
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify, request
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_mail import Mail
from werkzeug.exceptions import HTTPException

# Import all models to ensure they are known to SQLAlchemy before db.create_all()
from src.models.user import db, User # db is initialized here
from src.models.group import Group, Membership
from src.models.category_model import Category
from src.models.product_model import Product, ProductImage

# Import all blueprints
from src.routes.user import user_bp
from src.routes.group import group_bp
from src.routes.admin_user_routes import admin_user_bp
from src.routes.admin_group_routes import admin_group_bp
from src.routes.admin_category_routes import admin_category_bp # Import admin category routes
from src.routes.admin_product_routes import admin_product_bp # Import admin product routes

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Configuration
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'a_very_strong_default_secret_key_for_dev_only_please_change_this')
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'jam3yeti_db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "another_super_secret_jwt_key_change_it")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=24) # Increased for easier testing
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=30)

# Flask-Mail Configuration
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER', 'smtp.mailtrap.io')
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', '2525'))
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'True').lower() in ('true', '1', 't')
app.config['MAIL_USE_SSL'] = os.getenv('MAIL_USE_SSL', 'False').lower() in ('true', '1', 't')
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME', 'your_mailtrap_username')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD', 'your_mailtrap_password')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@jam3yeti.com')

# Initialize extensions
bcrypt = Bcrypt()
bcrypt.init_app(app) # Initialize Bcrypt with app

jwt = JWTManager()
jwt.init_app(app)

db.init_app(app) # Initialize SQLAlchemy with app

mail = Mail()
mail.init_app(app)

CORS(app, resources={r"/api/*": {"origins": "*"}, r"/admin/*": {"origins": "*"}})

# Register Blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(group_bp, url_prefix='/api')
app.register_blueprint(admin_user_bp, url_prefix='/admin/users')
app.register_blueprint(admin_group_bp, url_prefix='/admin/groups')
app.register_blueprint(admin_category_bp, url_prefix='/admin/categories') # Register admin category blueprint
app.register_blueprint(admin_product_bp, url_prefix='/admin/products') # Register admin product blueprint

# --- Error Handling ---
@app.errorhandler(HTTPException)
def handle_http_exception(e):
    response = e.get_response()
    response.data = jsonify({
        "code": e.code,
        "name": e.name,
        "description": e.description,
    })
    response.content_type = "application/json"
    return response

@app.errorhandler(404)
def page_not_found(e):
    if request.path.startswith('/api/') or request.path.startswith('/admin/'):
        return jsonify(message="Resource not found", error_code=404), 404
    # For serving frontend, try to return index.html for any other path
    static_folder_path = app.static_folder
    if static_folder_path and os.path.exists(os.path.join(static_folder_path, 'index.html')):
        return send_from_directory(static_folder_path, 'index.html')
    return jsonify(message="The requested URL was not found on the server.", error_code=404), 404

@app.errorhandler(500)
def internal_server_error(e):
    app.logger.error(f"Server Error: {e}, Path: {request.path}")
    return jsonify(message="An internal server error occurred.", error_code=500), 500

# --- End Error Handling ---

# Serve React App (static files)
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_react_app(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return jsonify(message="Static folder not configured"), 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            # This case should ideally be caught by the 404 handler if it's not an API route
            return jsonify(message="index.html not found in static folder."), 404

if __name__ == '__main__':
    with app.app_context():
        db.create_all() # Create database tables if they don't exist
    app.run(host='0.0.0.0', port=5000, debug=True)


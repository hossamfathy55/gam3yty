from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import User, db # Import db from user.py
# from src.models.product_model import Product # Import Product model

class Group(db.Model):
    __tablename__ = 'groups'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    # contribution_amount might be derived from product price and group discount logic later
    contribution_amount = db.Column(db.Numeric(10, 2), nullable=False)
    payout_frequency = db.Column(db.Enum('weekly', 'monthly', 'bi-monthly', name='payout_frequency_enum'), nullable=False)
    max_members = db.Column(db.Integer, nullable=False)
    current_members_count = db.Column(db.Integer, default=0)
    creator_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False) # Added product_id
    status = db.Column(db.Enum('pending', 'open_for_joining', 'active', 'completed', 'cancelled', name='group_status_enum'), default='pending')
    start_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    creator = db.relationship('User', backref=db.backref('created_groups', lazy=True))
    memberships = db.relationship('Membership', backref='group', lazy='dynamic', cascade="all, delete-orphan")
    # Relationship to Product model (many-to-one: many groups can be for one product, or one group for one product)
    product = db.relationship('Product', backref=db.backref('groups', lazy='dynamic'))

    def __repr__(self):
        return f'<Group {self.name}>'

    def to_dict(self, include_members=False, include_product_info=False):
        data = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'contribution_amount': str(self.contribution_amount) if self.contribution_amount is not None else None,
            'payout_frequency': self.payout_frequency,
            'max_members': self.max_members,
            'current_members_count': self.current_members_count,
            'creator_user_id': self.creator_user_id,
            'product_id': self.product_id,
            'status': self.status,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }
        if self.creator:
            data['creator_username'] = self.creator.username
        
        if include_product_info and self.product:
            data['product_name'] = self.product.name
            # Add more product details if needed, e.g., self.product.to_dict()

        if include_members:
            data['members'] = []
            for membership in self.memberships.all(): # Use .all() for dynamic relationship
                member_user = User.query.get(membership.user_id)
                if member_user:
                    data['members'].append({
                        'user_id': member_user.id,
                        'username': member_user.username,
                        'join_date': membership.join_date.isoformat() if membership.join_date else None,
                        'membership_status': membership.status,
                        'is_group_admin': membership.is_admin
                    })
        return data

class Membership(db.Model):
    __tablename__ = 'memberships'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('groups.id'), nullable=False)
    join_date = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    status = db.Column(db.Enum('pending_approval', 'active', 'left', 'removed', name='membership_status_enum'), default='pending_approval')
    payout_order_preference = db.Column(db.Integer, nullable=True)
    is_admin = db.Column(db.Boolean, default=False) # Indicates if the user is an admin of this specific group

    user = db.relationship('User', backref=db.backref('memberships', lazy='dynamic'))
    # Group relationship is already defined by backref in Group model

    __table_args__ = (db.UniqueConstraint('user_id', 'group_id', name='uq_user_group'),)

    def __repr__(self):
        return f'<Membership user_id={self.user_id} group_id={self.group_id}>'

    def to_dict(self):
        data = {
            'id': self.id,
            'user_id': self.user_id,
            'group_id': self.group_id,
            'join_date': self.join_date.isoformat() if self.join_date else None,
            'status': self.status,
            'payout_order_preference': self.payout_order_preference,
            'is_admin': self.is_admin
        }
        if self.user:
            data['username'] = self.user.username
        if self.group:
            data['group_name'] = self.group.name
        return data


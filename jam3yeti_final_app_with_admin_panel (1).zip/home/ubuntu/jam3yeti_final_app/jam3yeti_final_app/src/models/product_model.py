# src/models/product_model.py
from datetime import datetime
from src.models.user import db # Import db from a central place

class Product(db.Model):
    __tablename__ = 'products'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    base_price = db.Column(db.Numeric(10, 2), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False)
    # stock_quantity = db.Column(db.Integer, default=0) # As per design doc
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    images = db.relationship('ProductImage', backref='product', lazy='dynamic', cascade="all, delete-orphan")
    # groups relationship will be defined by backref in Group model

    def __repr__(self):
        return f'<Product {self.name}>'

    def to_dict(self, include_images=False, include_category=False):
        data = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'base_price': str(self.base_price) if self.base_price is not None else None,
            'category_id': self.category_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_images:
            data['images'] = [image.to_dict() for image in self.images]
        if include_category and hasattr(self, 'category') and self.category:
            data['category_name'] = self.category.name
        return data

class ProductImage(db.Model):
    __tablename__ = 'product_images'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    image_url = db.Column(db.String(512), nullable=False)
    is_primary = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)

    def __repr__(self):
        return f'<ProductImage {self.image_url} for product_id={self.product_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'product_id': self.product_id,
            'image_url': self.image_url,
            'is_primary': self.is_primary,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


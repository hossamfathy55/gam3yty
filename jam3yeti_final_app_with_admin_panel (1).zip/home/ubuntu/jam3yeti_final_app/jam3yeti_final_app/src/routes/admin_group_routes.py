# admin_group_routes.py
from flask import Blueprint, request, jsonify
from src.models.group import Group, Membership, db
from src.models.user import User # Needed for creator/member details
from flask_jwt_extended import jwt_required, get_jwt_identity
from functools import wraps
from datetime import datetime

admin_group_bp = Blueprint("admin_group_bp", __name__, url_prefix="/admin/groups")

# Decorator to check for admin privileges (assuming it's defined elsewhere or copied here)
# For now, let's copy the definition for clarity, or it should be in a shared utility module
def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            return jsonify({"message": "Admin access required"}), 403
        return fn(*args, **kwargs)
    return wrapper

@admin_group_bp.route("", methods=["GET"])
@jwt_required()
@admin_required
def get_all_groups_admin():
    """Get a list of all groups (admin only)."""
    try:
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 10, type=int)
        groups_pagination = Group.query.paginate(page=page, per_page=per_page, error_out=False)
        groups = groups_pagination.items
        output = []
        for group in groups:
            creator = User.query.get(group.creator_user_id)
            group_data = {
                "id": group.id,
                "name": group.name,
                "description": group.description,
                "contribution_amount": float(group.contribution_amount) if group.contribution_amount else None,
                "payout_frequency": group.payout_frequency,
                "max_members": group.max_members,
                "current_members_count": group.current_members_count,
                "creator_user_id": group.creator_user_id,
                "creator_username": creator.username if creator else "N/A",
                "status": group.status,
                "start_date": group.start_date.isoformat() if group.start_date else None,
                "created_at": group.created_at.isoformat() if group.created_at else None
            }
            output.append(group_data)
        return jsonify({
            "groups": output,
            "total": groups_pagination.total,
            "pages": groups_pagination.pages,
            "current_page": groups_pagination.page
        }), 200
    except Exception as e:
        return jsonify({"message": "Failed to retrieve groups", "error": str(e)}), 500

@admin_group_bp.route("/<int:group_id>", methods=["GET"])
@jwt_required()
@admin_required
def get_group_details_admin(group_id):
    """Get details of a specific group, including members (admin only)."""
    group = Group.query.get(group_id)
    if not group:
        return jsonify({"message": "Group not found"}), 404
    
    creator = User.query.get(group.creator_user_id)
    group_data = {
        "id": group.id,
        "name": group.name,
        "description": group.description,
        "contribution_amount": float(group.contribution_amount) if group.contribution_amount else None,
        "payout_frequency": group.payout_frequency,
        "max_members": group.max_members,
        "current_members_count": group.current_members_count,
        "creator_user_id": group.creator_user_id,
        "creator_username": creator.username if creator else "N/A",
        "status": group.status,
        "start_date": group.start_date.isoformat() if group.start_date else None,
        "created_at": group.created_at.isoformat() if group.created_at else None,
        "members": []
    }
    memberships = Membership.query.filter_by(group_id=group.id).all()
    for membership in memberships:
        member_user = User.query.get(membership.user_id)
        if member_user:
            group_data["members"].append({
                "user_id": member_user.id, 
                "username": member_user.username, 
                "join_date": membership.join_date.isoformat(),
                "membership_status": membership.status,
                "is_group_admin": membership.is_admin
            })
    return jsonify(group_data), 200

@admin_group_bp.route("", methods=["POST"])
@jwt_required()
@admin_required
def create_group_admin():
    """Create a new group by admin."""
    data = request.get_json()
    current_admin_id = get_jwt_identity() # Admin creating the group

    required_fields = ["name", "contribution_amount", "payout_frequency", "max_members"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": "Missing required fields"}), 400

    try:
        new_group = Group(
            name=data["name"],
            description=data.get("description"),
            contribution_amount=data["contribution_amount"],
            payout_frequency=data["payout_frequency"],
            max_members=data["max_members"],
            creator_user_id=data.get("creator_user_id", current_admin_id), # Can specify a creator or defaults to admin
            status=data.get("status", "open_for_joining"),
            start_date=datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        )
        db.session.add(new_group)
        db.session.commit()
        # Optionally, add the specified creator (if different from admin) or admin as the first member
        # This part needs careful consideration based on desired logic
        return jsonify({"message": "Group created successfully by admin", "group_id": new_group.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to create group by admin", "error": str(e)}), 500

@admin_group_bp.route("/<int:group_id>", methods=["PUT"])
@jwt_required()
@admin_required
def update_group_admin(group_id):
    """Update group details by admin."""
    group = Group.query.get(group_id)
    if not group:
        return jsonify({"message": "Group not found"}), 404

    data = request.get_json()
    if "name" in data: group.name = data["name"]
    if "description" in data: group.description = data["description"]
    if "contribution_amount" in data: group.contribution_amount = data["contribution_amount"]
    if "payout_frequency" in data: group.payout_frequency = data["payout_frequency"]
    if "max_members" in data: group.max_members = data["max_members"]
    if "status" in data: group.status = data["status"]
    if "start_date" in data:
        group.start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    # Add other updatable fields as necessary

    try:
        db.session.commit()
        return jsonify({"message": "Group updated successfully by admin"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to update group by admin", "error": str(e)}), 500

@admin_group_bp.route("/<int:group_id>", methods=["DELETE"])
@jwt_required()
@admin_required
def delete_group_admin(group_id):
    """Delete a group by admin."""
    group = Group.query.get(group_id)
    if not group:
        return jsonify({"message": "Group not found"}), 404

    try:
        # Memberships are cascade deleted due to model definition `cascade="all, delete-orphan"` on Group.memberships
        db.session.delete(group)
        db.session.commit()
        return jsonify({"message": "Group deleted successfully by admin"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to delete group by admin", "error": str(e)}), 500

# --- Admin - Membership Management in a Group ---

@admin_group_bp.route("/<int:group_id>/members", methods=["POST"])
@jwt_required()
@admin_required
def add_member_to_group_admin(group_id):
    """Admin adds a user to a specific group."""
    data = request.get_json()
    user_id_to_add = data.get("user_id")

    if not user_id_to_add:
        return jsonify({"message": "User ID to add is required"}), 400

    group = Group.query.get(group_id)
    if not group:
        return jsonify({"message": "Group not found"}), 404
    
    user_to_add = User.query.get(user_id_to_add)
    if not user_to_add:
        return jsonify({"message": "User to add not found"}), 404

    if group.current_members_count >= group.max_members:
        return jsonify({"message": "Group is full"}), 403

    existing_membership = Membership.query.filter_by(user_id=user_id_to_add, group_id=group_id).first()
    if existing_membership and existing_membership.status == 'active':
        return jsonify({"message": "User is already an active member of this group"}), 409
    if existing_membership and existing_membership.status != 'left': # e.g. pending, removed
         return jsonify({"message": f"User has a non-active status ('{existing_membership.status}') in this group. Please resolve manually or update status."}), 409

    try:
        if existing_membership and existing_membership.status == 'left':
            # Re-activate if user left previously
            existing_membership.status = 'active'
            existing_membership.join_date = datetime.utcnow()
            existing_membership.is_admin = data.get("is_group_admin", False) # Optionally set as group admin
        else:
            new_membership = Membership(
                user_id=user_id_to_add,
                group_id=group_id,
                status='active', # Admin adding directly, so active
                is_admin=data.get("is_group_admin", False) # Optionally set as group admin
            )
            db.session.add(new_membership)
        
        group.current_members_count = Membership.query.filter_by(group_id=group_id, status='active').count() # Recalculate accurately
        db.session.commit()
        return jsonify({"message": f"User {user_to_add.username} added to group {group.name} successfully"}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to add member to group", "error": str(e)}), 500

@admin_group_bp.route("/<int:group_id>/members/<int:user_id>", methods=["DELETE"])
@jwt_required()
@admin_required
def remove_member_from_group_admin(group_id, user_id):
    """Admin removes a user from a specific group."""
    membership = Membership.query.filter_by(user_id=user_id, group_id=group_id).first()
    if not membership:
        return jsonify({"message": "Membership not found for this user in this group"}), 404

    group = Group.query.get(group_id)
    if not group: # Should not happen if membership exists
        return jsonify({"message": "Group not found"}), 404

    # Prevent removing the group creator if they are the only admin or specific policies
    # This logic can be complex and depends on requirements.
    # For now, allow removal by system admin.

    try:
        # Option 1: Hard delete membership
        db.session.delete(membership)
        # Option 2: Set status to 'removed'
        # membership.status = 'removed'
        
        # Update member count
        group.current_members_count = Membership.query.filter_by(group_id=group_id, status='active').count() - (1 if membership.status == 'active' else 0)
        if group.current_members_count < 0: group.current_members_count = 0
        
        db.session.commit()
        return jsonify({"message": "Member removed from group successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to remove member from group", "error": str(e)}), 500

@admin_group_bp.route("/<int:group_id>/members/<int:user_id>/status", methods=["PUT"])
@jwt_required()
@admin_required
def update_member_status_in_group_admin(group_id, user_id):
    """Admin updates a member's status or group admin role in a specific group."""
    data = request.get_json()
    membership = Membership.query.filter_by(user_id=user_id, group_id=group_id).first()

    if not membership:
        return jsonify({"message": "Membership not found"}), 404

    if "status" in data and data["status"] in ["pending_approval", "active", "left", "removed"]:
        membership.status = data["status"]
    
    if "is_group_admin" in data and isinstance(data["is_group_admin"], bool):
        membership.is_admin = data["is_group_admin"]

    try:
        db.session.commit()
        # Recalculate active member count if status changed
        group = Group.query.get(group_id)
        if group:
            group.current_members_count = Membership.query.filter_by(group_id=group_id, status='active').count()
            db.session.commit() # Commit again if group count changed

        return jsonify({"message": "Member status/role updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to update member status/role", "error": str(e)}), 500



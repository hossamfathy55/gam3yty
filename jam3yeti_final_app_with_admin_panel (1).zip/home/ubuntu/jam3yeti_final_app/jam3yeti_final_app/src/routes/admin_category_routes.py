# src/routes/admin_category_routes.py
from flask import Blueprint, request, jsonify
from src.models.category_model import Category, db 
from src.models.user import User 
from flask_jwt_extended import jwt_required, get_jwt_identity
from functools import wraps
import os 
from werkzeug.utils import secure_filename 

admin_category_bp = Blueprint("admin_category_bp", __name__, url_prefix="/admin/categories")

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            return jsonify({"message": "Admin access required"}), 403
        return fn(*args, **kwargs)
    return wrapper

@admin_category_bp.route("", methods=["POST"])
@jwt_required()
@admin_required
def create_category_admin():
    data = request.form 
    if not data or "name" not in data:
        return jsonify({"message": "Category name is required"}), 400

    name = data["name"]
    description = data.get("description")
    image_url_from_request = data.get("image_url") 
    image_file = request.files.get("image_file")
    final_image_url = image_url_from_request

    # Placeholder for image upload logic
    # if image_file:
    #     filename = secure_filename(image_file.filename)
    #     # image_path = os.path.join(UPLOAD_FOLDER, filename)
    #     # image_file.save(image_path)
    #     # final_image_url = f"/uploads/categories/{filename}"
    #     pass

    if Category.query.filter_by(name=name).first():
        return jsonify({"message": f"Category with name '{name}' already exists"}), 409

    try:
        new_category = Category(
            name=name,
            description=description,
            image_url=final_image_url
        )
        db.session.add(new_category)
        db.session.commit()
        return jsonify({"message": "Category created successfully", "category": new_category.to_dict()}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to create category", "error": str(e)}), 500

@admin_category_bp.route("", methods=["GET"])
@jwt_required()
@admin_required
def get_all_categories_admin():
    try:
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 10, type=int)
        categories_pagination = Category.query.paginate(page=page, per_page=per_page, error_out=False)
        categories = categories_pagination.items
        
        return jsonify({
            "categories": [category.to_dict() for category in categories],
            "total": categories_pagination.total,
            "pages": categories_pagination.pages,
            "current_page": categories_pagination.page
        }), 200
    except Exception as e:
        return jsonify({"message": "Failed to retrieve categories", "error": str(e)}), 500

@admin_category_bp.route("/<int:category_id>", methods=["GET"])
@jwt_required()
@admin_required
def get_category_details_admin(category_id):
    category = Category.query.get(category_id)
    if not category:
        return jsonify({"message": "Category not found"}), 404
    return jsonify({"category": category.to_dict()}), 200

@admin_category_bp.route("/<int:category_id>", methods=["PUT"])
@jwt_required()
@admin_required
def update_category_admin(category_id):
    category = Category.query.get(category_id)
    if not category:
        return jsonify({"message": "Category not found"}), 404

    data = request.form 
    if not data:
        return jsonify({"message": "No input data provided"}), 400

    if "name" in data:
        new_name = data["name"]
        if new_name != category.name and Category.query.filter_by(name=new_name).first():
            return jsonify({"message": f"Category with name '{new_name}' already exists"}), 409
        category.name = new_name
    
    if "description" in data:
        category.description = data["description"]
    
    if "image_url" in data:
        category.image_url = data["image_url"]

    # Placeholder for image file update
    # image_file = request.files.get("image_file")
    # if image_file:
    #     # ... (similar upload logic as in create_category_admin) ...
    #     # category.image_url = new_image_file_url
    #     pass

    try:
        db.session.commit()
        return jsonify({"message": "Category updated successfully", "category": category.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to update category", "error": str(e)}), 500

@admin_category_bp.route("/<int:category_id>", methods=["DELETE"])
@jwt_required()
@admin_required
def delete_category_admin(category_id):
    category = Category.query.get(category_id)
    if not category:
        return jsonify({"message": "Category not found"}), 404

    if category.products.first(): 
        return jsonify({"message": "Cannot delete category. It is associated with existing products."}), 400

    try:
        db.session.delete(category)
        db.session.commit()
        return jsonify({"message": "Category deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to delete category", "error": str(e)}), 500


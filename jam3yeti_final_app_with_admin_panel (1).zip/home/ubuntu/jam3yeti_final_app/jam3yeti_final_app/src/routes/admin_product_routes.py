# src/routes/admin_product_routes.py
from flask import Blueprint, request, jsonify
from src.models.product_model import Product, ProductImage, db # Assuming Product models are in product_model.py
from src.models.category_model import Category # To link products to categories
from src.models.user import User # For admin check
from flask_jwt_extended import jwt_required, get_jwt_identity
from functools import wraps
import os
from werkzeug.utils import secure_filename

# Define a path for image uploads if you plan to store them locally
# UPLOAD_FOLDER_PRODUCTS = os.path.join(os.getcwd(), "uploads/products")
# if not os.path.exists(UPLOAD_FOLDER_PRODUCTS):
#     os.makedirs(UPLOAD_FOLDER_PRODUCTS)

admin_product_bp = Blueprint("admin_product_bp", __name__, url_prefix="/admin/products")

# Admin required decorator (should be shared)
def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            return jsonify({"message": "Admin access required"}), 403
        return fn(*args, **kwargs)
    return wrapper

@admin_product_bp.route("", methods=["POST"])
@jwt_required()
@admin_required
def create_product_admin():
    """Admin creates a new product."""
    data = request.form
    if not data or not all(k in data for k in ["name", "base_price", "category_id"]):
        return jsonify({"message": "Missing required fields: name, base_price, category_id"}), 400

    name = data["name"]
    description = data.get("description")
    base_price = data["base_price"]
    category_id = data["category_id"]

    if not Category.query.get(category_id):
        return jsonify({"message": "Category not found"}), 404
    
    # Placeholder for image handling - assuming image URLs are sent or handled by a separate endpoint for now
    # For multiple image uploads, request.files.getlist("image_files") would be used.

    try:
        new_product = Product(
            name=name,
            description=description,
            base_price=base_price,
            category_id=category_id
        )
        db.session.add(new_product)
        db.session.commit() # Commit to get product ID for images

        # Example: If image URLs are passed directly in form data as a list or comma-separated string
        # image_urls_str = data.get("image_urls") # e.g., "url1,url2,url3"
        # if image_urls_str:
        #     urls = [url.strip() for url in image_urls_str.split(",")]
        #     for i, url in enumerate(urls):
        #         img = ProductImage(product_id=new_product.id, image_url=url, is_primary=(i==0))
        #         db.session.add(img)
        #     db.session.commit()

        return jsonify({"message": "Product created successfully", "product": new_product.to_dict(include_images=True)}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to create product", "error": str(e)}), 500

@admin_product_bp.route("", methods=["GET"])
@jwt_required()
@admin_required
def get_all_products_admin():
    """Admin gets a list of all products."""
    try:
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 10, type=int)
        query = Product.query

        category_filter = request.args.get("category_id")
        if category_filter:
            query = query.filter(Product.category_id == category_filter)
        
        search_term = request.args.get("search")
        if search_term:
            query = query.filter(Product.name.ilike(f"%{search_term}%"))

        products_pagination = query.order_by(Product.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
        products = products_pagination.items
        
        return jsonify({
            "products": [product.to_dict(include_images=True, include_category=True) for product in products],
            "total": products_pagination.total,
            "pages": products_pagination.pages,
            "current_page": products_pagination.page
        }), 200
    except Exception as e:
        return jsonify({"message": "Failed to retrieve products", "error": str(e)}), 500

@admin_product_bp.route("/<int:product_id>", methods=["GET"])
@jwt_required()
@admin_required
def get_product_details_admin(product_id):
    """Admin gets details of a specific product."""
    product = Product.query.get(product_id)
    if not product:
        return jsonify({"message": "Product not found"}), 404
    return jsonify({"product": product.to_dict(include_images=True, include_category=True)}), 200

@admin_product_bp.route("/<int:product_id>", methods=["PUT"])
@jwt_required()
@admin_required
def update_product_admin(product_id):
    """Admin updates a product."""
    product = Product.query.get(product_id)
    if not product:
        return jsonify({"message": "Product not found"}), 404

    data = request.form # Or request.get_json() if not sending files
    if not data:
        return jsonify({"message": "No input data provided"}), 400

    if "name" in data: product.name = data["name"]
    if "description" in data: product.description = data["description"]
    if "base_price" in data: product.base_price = data["base_price"]
    if "category_id" in data:
        if not Category.query.get(data["category_id"]):
            return jsonify({"message": "Category not found"}), 404
        product.category_id = data["category_id"]
    
    # Image updates would typically be handled by adding/deleting images via separate endpoints
    # or by passing a list of image URLs to keep.

    try:
        db.session.commit()
        return jsonify({"message": "Product updated successfully", "product": product.to_dict(include_images=True, include_category=True)}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to update product", "error": str(e)}), 500

@admin_product_bp.route("/<int:product_id>", methods=["DELETE"])
@jwt_required()
@admin_required
def delete_product_admin(product_id):
    """Admin deletes a product."""
    product = Product.query.get(product_id)
    if not product:
        return jsonify({"message": "Product not found"}), 404

    # Check if product is associated with any groups before deleting
    if product.groups.first():
        return jsonify({"message": "Cannot delete product. It is associated with existing groups."}), 400

    try:
        # Associated ProductImages will be cascade deleted due to model definition
        db.session.delete(product)
        db.session.commit()
        return jsonify({"message": "Product deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to delete product", "error": str(e)}), 500

# --- Product Image Management by Admin ---

@admin_product_bp.route("/<int:product_id>/images", methods=["POST"])
@jwt_required()
@admin_required
def add_product_image_admin(product_id):
    """Admin adds an image to a product. Assumes image file upload."""
    product = Product.query.get(product_id)
    if not product:
        return jsonify({"message": "Product not found"}), 404

    if "image_file" not in request.files:
        return jsonify({"message": "No image file provided"}), 400
    
    image_file = request.files["image_file"]
    is_primary = request.form.get("is_primary", "false").lower() == "true"

    if image_file.filename == "":
        return jsonify({"message": "No selected file"}), 400

    # Placeholder for actual file upload logic to a CDN or local storage
    # filename = secure_filename(image_file.filename)
    # image_path = os.path.join(UPLOAD_FOLDER_PRODUCTS, filename) # Ensure UPLOAD_FOLDER_PRODUCTS is defined
    # image_file.save(image_path)
    # image_url_for_db = f"/uploads/products/{filename}" # This URL needs to be publicly accessible
    # For now, let's assume a placeholder URL or that the frontend handles uploads to a service and sends URL
    # This part is CRITICAL and needs a proper implementation for image hosting.
    # For demonstration, we will use a placeholder for image_url.
    # In a real app, you would upload to S3, Cloudinary, etc., and store the returned URL.
    image_url_for_db = f"placeholder_image_path_for_{secure_filename(image_file.filename)}" 

    try:
        if is_primary:
            # Set other images of this product to not be primary
            ProductImage.query.filter_by(product_id=product_id, is_primary=True).update({"is_primary": False})

        new_image = ProductImage(
            product_id=product_id,
            image_url=image_url_for_db, # This should be the actual URL after upload
            is_primary=is_primary
        )
        db.session.add(new_image)
        db.session.commit()
        return jsonify({"message": "Image added to product successfully", "image": new_image.to_dict()}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to add image to product", "error": str(e)}), 500

@admin_product_bp.route("/<int:product_id>/images/<int:image_id>", methods=["DELETE"])
@jwt_required()
@admin_required
def delete_product_image_admin(product_id, image_id):
    """Admin deletes an image from a product."""
    image = ProductImage.query.filter_by(id=image_id, product_id=product_id).first()
    if not image:
        return jsonify({"message": "Image not found for this product"}), 404
    
    # Placeholder: If images are stored locally, you might want to delete the file from disk here
    # if os.path.exists(image.image_url_on_disk): # Assuming you store local path too
    #     os.remove(image.image_url_on_disk)

    try:
        db.session.delete(image)
        db.session.commit()
        return jsonify({"message": "Image deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to delete image", "error": str(e)}), 500

@admin_product_bp.route("/<int:product_id>/images/<int:image_id>/set_primary", methods=["PUT"])
@jwt_required()
@admin_required
def set_primary_product_image_admin(product_id, image_id):
    """Admin sets an image as primary for a product."""
    image_to_set_primary = ProductImage.query.filter_by(id=image_id, product_id=product_id).first()
    if not image_to_set_primary:
        return jsonify({"message": "Image not found for this product"}), 404

    try:
        # Set all other images for this product to not be primary
        ProductImage.query.filter(ProductImage.product_id == product_id, ProductImage.id != image_id).update({"is_primary": False})
        # Set the selected image as primary
        image_to_set_primary.is_primary = True
        db.session.commit()
        return jsonify({"message": "Primary image set successfully", "image": image_to_set_primary.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to set primary image", "error": str(e)}), 500


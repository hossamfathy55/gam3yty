# admin_user_routes.py
from flask import Blueprint, request, jsonify
from src.models.user import User, db
from src.models.group import Group, Membership # Import Group and Membership if needed for user details
from flask_jwt_extended import jwt_required, get_jwt_identity
from functools import wraps

admin_user_bp = Blueprint("admin_user_bp", __name__, url_prefix="/admin/users")

# Decorator to check for admin privileges
def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            return jsonify({"message": "Admin access required"}), 403
        return fn(*args, **kwargs)
    return wrapper

@admin_user_bp.route("", methods=["GET"])
@jwt_required()
@admin_required
def get_all_users():
    """Get a list of all users (admin only)."""
    try:
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 10, type=int)
        users_pagination = User.query.paginate(page=page, per_page=per_page, error_out=False)
        users = users_pagination.items
        output = []
        for user in users:
            user_data = {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "is_admin": user.is_admin,
                "is_active": user.is_active,
                "created_at": user.created_at.isoformat() if user.created_at else None,
                "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None
            }
            output.append(user_data)
        return jsonify({
            "users": output,
            "total": users_pagination.total,
            "pages": users_pagination.pages,
            "current_page": users_pagination.page
        }), 200
    except Exception as e:
        return jsonify({"message": "Failed to retrieve users", "error": str(e)}), 500

@admin_user_bp.route("/<int:user_id>", methods=["GET"])
@jwt_required()
@admin_required
def get_user_details_admin(user_id):
    """Get details of a specific user (admin only)."""
    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404
    
    user_data = {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "full_name": user.full_name,
        "is_admin": user.is_admin,
        "is_active": user.is_active,
        "created_at": user.created_at.isoformat() if user.created_at else None,
        "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None
        # Add more details if needed, e.g., groups joined
    }
    return jsonify(user_data), 200

@admin_user_bp.route("/<int:user_id>", methods=["PUT"])
@jwt_required()
@admin_required
def update_user_admin(user_id):
    """Update user details by admin (e.g., is_admin, is_active)."""
    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    data = request.get_json()
    if not data:
        return jsonify({"message": "No input data provided"}), 400

    if "is_admin" in data and isinstance(data["is_admin"], bool):
        user.is_admin = data["is_admin"]
    if "is_active" in data and isinstance(data["is_active"], bool):
        user.is_active = data["is_active"]
    if "full_name" in data:
        user.full_name = data["full_name"]
    # Add other updatable fields as necessary, e.g., email, username (with uniqueness checks)

    try:
        db.session.commit()
        return jsonify({"message": "User updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to update user", "error": str(e)}), 500

@admin_user_bp.route("/<int:user_id>", methods=["DELETE"])
@jwt_required()
@admin_required
def delete_user_admin(user_id):
    """Delete a user by admin (consider soft delete)."""
    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    # Prevent admin from deleting themselves (optional, based on policy)
    # current_admin_id = get_jwt_identity()
    # if user.id == current_admin_id:
    #     return jsonify({"message": "Admin cannot delete their own account"}), 403

    try:
        # For soft delete, you might set user.is_active = False or add a deleted_at field
        # For hard delete:
        db.session.delete(user)
        db.session.commit()
        return jsonify({"message": "User deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        # Handle cases where user cannot be deleted due to foreign key constraints (e.g., group creator)
        return jsonify({"message": "Failed to delete user", "error": str(e)}), 500


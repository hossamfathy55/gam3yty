from flask import Blueprint, request, jsonify
from src.models.group import Group, Membership, db
from src.models.user import User # Needed for checking creator/user existence
from flask_jwt_extended import jwt_required, get_jwt_identity # Import JWT functions
from datetime import datetime

group_bp = Blueprint("group_bp", __name__)

# --- Group CRUD Operations ---
@group_bp.route("/groups", methods=["POST"])
@jwt_required()
def create_group():
    data = request.get_json()
    current_user_id = get_jwt_identity()

    required_fields = ["name", "contribution_amount", "payout_frequency", "max_members"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": "Missing required fields for group creation"}), 400

    if not isinstance(data["max_members"], int) or data["max_members"] <= 0:
        return jsonify({"message": "max_members must be a positive integer"}), 400
    
    if data["payout_frequency"] not in ["weekly", "monthly", "bi-monthly"]:
        return jsonify({"message": "Invalid payout_frequency"}), 400

    new_group = Group(
        name=data["name"],
        description=data.get("description"),
        contribution_amount=data["contribution_amount"],
        payout_frequency=data["payout_frequency"],
        max_members=data["max_members"],
        creator_user_id=current_user_id, # Set creator to the authenticated user
        status=data.get("status", "open_for_joining"), # Default to open_for_joining
        start_date=datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    )

    try:
        db.session.add(new_group)
        db.session.commit() # Commit to get new_group.id

        # Add the creator as the first member and admin
        creator_membership = Membership(
            user_id=current_user_id,
            group_id=new_group.id,            status='active',            is_admin=True
        )
        db.session.add(creator_membership)
        new_group.current_members_count = 1
        db.session.commit()
        return jsonify({"message": "Group created successfully", "group_id": new_group.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to create group", "error": str(e)}), 500

@group_bp.route("/groups", methods=["GET"])
# No JWT required for browsing all groups, can be public
def get_all_groups():
    groups = Group.query.filter(Group.status != 'pending').all() # Filter out pending groups from public view
    output = []
    for group in groups:
        group_data = {
            "id": group.id,
            "name": group.name,
            "description": group.description,
            "contribution_amount": float(group.contribution_amount) if group.contribution_amount else None,
            "payout_frequency": group.payout_frequency,
            "max_members": group.max_members,
            "current_members_count": group.current_members_count,
            "creator_user_id": group.creator_user_id,
            "status": group.status,
            "start_date": group.start_date.isoformat() if group.start_date else None,
            "created_at": group.created_at.isoformat() if group.created_at else None
        }
        output.append(group_data)
    return jsonify({"groups": output}), 200

@group_bp.route("/groups/<int:group_id>", methods=["GET"])
# No JWT required for viewing a specific group, can be public
def get_group_details(group_id):
    group = Group.query.get(group_id)
    if not group or group.status == 'pending': # Hide pending groups from direct access unless by creator/admin
        return jsonify({"message": "Group not found or not accessible"}), 404
    
    group_data = {
        "id": group.id,
        "name": group.name,
        "description": group.description,
        "contribution_amount": float(group.contribution_amount) if group.contribution_amount else None,
        "payout_frequency": group.payout_frequency,
        "max_members": group.max_members,
        "current_members_count": group.current_members_count,
        "creator_user_id": group.creator_user_id,
        "status": group.status,
        "start_date": group.start_date.isoformat() if group.start_date else None,
        "created_at": group.created_at.isoformat() if group.created_at else None,
        "members": []
    }
    memberships = Membership.query.filter_by(group_id=group.id, status='active').all()
    for membership in memberships:
        user = User.query.get(membership.user_id)
        if user:
            group_data["members"].append({"user_id": user.id, "username": user.username, "join_date": membership.join_date.isoformat()})

    return jsonify(group_data), 200

@group_bp.route("/groups/<int:group_id>", methods=["PUT"])
@jwt_required()
def update_group_details(group_id):
    group = Group.query.get(group_id)
    if not group:
        return jsonify({"message": "Group not found"}), 404

    current_user_id = get_jwt_identity()
    if group.creator_user_id != current_user_id:
        # Add logic here if group admins (not just creator) can update
        return jsonify({"message": "Unauthorized to update this group"}), 403

    data = request.get_json()
    # Allow updating specific fields, e.g., name, description, status (with validation)
    if "name" in data: group.name = data["name"]
    if "description" in data: group.description = data["description"]
    if "status" in data and data["status"] in ["open_for_joining", "active", "completed", "cancelled"]:
        group.status = data["status"]
    # Add more updatable fields as needed with validation

    try:
        db.session.commit()
        return jsonify({"message": "Group updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to update group", "error": str(e)}), 500

@group_bp.route("/groups/<int:group_id>", methods=["DELETE"])
@jwt_required()
def delete_group_permanently(group_id):
    group = Group.query.get(group_id)
    if not group:
        return jsonify({"message": "Group not found"}), 404

    current_user_id = get_jwt_identity()
    if group.creator_user_id != current_user_id:
        return jsonify({"message": "Unauthorized to delete this group"}), 403
    
    # Consider soft delete (e.g., changing status to 'deleted') instead of hard delete
    # For hard delete:
    try:
        # Memberships are cascade deleted due to model definition
        db.session.delete(group)
        db.session.commit()
        return jsonify({"message": "Group deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to delete group", "error": str(e)}), 500

# --- Membership Operations ---

@group_bp.route("/groups/<int:group_id>/join", methods=["POST"])
@jwt_required()
def join_group_request(group_id):
    current_user_id = get_jwt_identity()
    group = Group.query.get(group_id)

    if not group:
        return jsonify({"message": "Group not found"}), 404

    if group.status != 'open_for_joining':
        return jsonify({"message": f"Group is not open for joining. Current status: {group.status}"}), 403

    if group.current_members_count >= group.max_members:
        return jsonify({"message": "Group is full"}), 403

    existing_membership = Membership.query.filter_by(user_id=current_user_id, group_id=group_id).first()
    if existing_membership:
        if existing_membership.status == 'active':
            return jsonify({"message": "User is already an active member of this group"}), 409
        # Add other statuses if needed (e.g. pending_approval, left)
        return jsonify({"message": "User has a pending status or was previously a member."}), 409

    new_membership = Membership(
        user_id=current_user_id,
        group_id=group_id,
        status='active' # Auto-approve for now, or change to 'pending_approval'
    )

    try:
        db.session.add(new_membership)
        group.current_members_count += 1
        db.session.commit()
        return jsonify({"message": "Successfully joined group", "membership_id": new_membership.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to join group", "error": str(e)}), 500

@group_bp.route("/groups/<int:group_id>/leave", methods=["POST"])
@jwt_required()
def leave_group_request(group_id):
    current_user_id = get_jwt_identity()
    membership = Membership.query.filter_by(user_id=current_user_id, group_id=group_id, status='active').first()

    if not membership:
        return jsonify({"message": "User is not an active member of this group"}), 404
    
    group = Group.query.get(group_id)
    if not group: # Should not happen if membership exists
        return jsonify({"message": "Group not found"}), 404

    if group.creator_user_id == current_user_id and group.current_members_count > 1:
        # Basic check: Creator cannot leave if other members exist. More complex logic for transferring ownership might be needed.
        return jsonify({"message": "Creator cannot leave the group if other members are present. Consider deleting the group or transferring ownership."}), 403
    if group.creator_user_id == current_user_id and group.current_members_count == 1:
        # If creator is the only member, leaving is akin to deleting the group or making it inactive.
        # For simplicity, we can delete the membership and the group here, or just the membership and let the group become empty.
        # Let's just remove membership and decrement count. Group deletion should be explicit.
        pass # Allow creator to leave if they are the only one.

    try:
        # Instead of deleting, set status to 'left' to keep history
        # membership.status = 'left'
        # For hard delete of membership:
        db.session.delete(membership)
        if group.current_members_count > 0:
             group.current_members_count -= 1
        db.session.commit()
        return jsonify({"message": "Successfully left the group"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to leave group", "error": str(e)}), 500

# TODO: Add routes for managing group members by admin/creator (e.g., remove member, approve join requests if status is pending_approval)



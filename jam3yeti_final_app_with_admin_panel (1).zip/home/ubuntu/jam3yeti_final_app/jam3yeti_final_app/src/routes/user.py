from flask import Blueprint, request, jsonify, current_app
from src.models.user import User, db
from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, get_jwt_identity
from flask_mail import Message
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadTimeSignature
from datetime import datetime, timedelta
import re # For email and password validation

# It's good practice to get mail instance from current_app if routes are in a blueprint
# However, mail is initialized in main.py and can be imported if structured differently.
# For simplicity here, assuming mail can be accessed or passed if needed.
# from src.main import mail # This might cause circular import if main imports user_bp before mail is initialized.
# A common pattern is to initialize extensions in create_app() and pass app or extensions around.
# For now, we will get mail from current_app.extensions['mail'] if available or handle it carefully.

user_bp = Blueprint("user_bp", __name__)

# --- Input Validation Helpers ---
def is_valid_email(email):
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    return re.match(pattern, email) is not None

def is_strong_password(password):
    if len(password) < 8:
        return False
    if not re.search(r"[A-Z]", password):
        return False
    if not re.search(r"[a-z]", password):
        return False
    if not re.search(r"\d", password):
        return False
    if not re.search(r"[!@#$%^&*()-_=+{};:,<.>]", password):
        return False
    return True

# --- Token Serializer for Password Reset ---
def get_reset_token_serializer():
    return URLSafeTimedSerializer(current_app.config['SECRET_KEY'])

# --- User Routes ---
@user_bp.route("/auth/register", methods=["POST"])
def register_user():
    data = request.get_json()
    errors = {}
    required_fields = ["username", "email", "password", "full_name"]
    for field in required_fields:
        if not data or not data.get(field):
            errors[field] = "This field is required."
    if errors: return jsonify({"message": "Validation errors", "errors": errors}), 400

    username = data.get("username", "").strip()
    if not (3 <= len(username) <= 50):
        errors["username"] = "Username must be between 3 and 50 characters."
    elif not username.isalnum():
        errors["username"] = "Username can only contain alphanumeric characters."
    elif User.query.filter_by(username=username).first():
        errors["username"] = "Username already exists."

    email = data.get("email", "").strip()
    if not email:
        errors["email"] = "Email is required."
    elif not is_valid_email(email):
        errors["email"] = "Invalid email format."
    elif User.query.filter_by(email=email).first():
        errors["email"] = "Email already exists."

    password = data.get("password", "")
    if not password:
        errors["password"] = "Password is required."
    elif not is_strong_password(password):
        errors["password"] = "Password must be at least 8 characters long and include an uppercase letter, a lowercase letter, a digit, and a special character."

    full_name = data.get("full_name", "").strip()
    if not (2 <= len(full_name) <= 100):
        errors["full_name"] = "Full name must be between 2 and 100 characters."

    if errors: return jsonify({"message": "Validation errors", "errors": errors}), 400

    new_user = User(username=username, email=email, full_name=full_name)
    new_user.set_password(password)
    
    try:
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"message": "User registered successfully", "user_id": new_user.id}), 201
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error registering user: {str(e)}")
        return jsonify({"message": "Failed to register user", "error": "An internal error occurred."}), 500

@user_bp.route("/auth/login", methods=["POST"])
def login_user():
    data = request.get_json()
    errors = {}
    email = data.get("email", "").strip()
    password = data.get("password", "")

    if not email:
        errors["email"] = "Email is required."
    elif not is_valid_email(email):
         errors["email"] = "Invalid email format."
    if not password:
        errors["password"] = "Password is required."
    if errors: return jsonify({"message": "Validation errors", "errors": errors}), 400

    user = User.query.filter_by(email=email).first()
    if user and user.check_password(password):
        if not user.is_active:
            return jsonify({"message": "User account is inactive"}), 403
        
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)
        user.last_login_at = datetime.utcnow()
        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating last_login_at for user {user.id}: {str(e)}")
        return jsonify({
            "message": "Login successful",
            "access_token": access_token,
            "refresh_token": refresh_token,
            "user_id": user.id,
            "username": user.username
        }), 200
    else:
        return jsonify({"message": "Invalid email or password"}), 401

@user_bp.route("/auth/forgot-password", methods=["POST"])
def forgot_password():
    data = request.get_json()
    email = data.get("email", "").strip()
    if not email or not is_valid_email(email):
        return jsonify({"message": "Valid email is required"}), 400

    user = User.query.filter_by(email=email).first()
    if user:
        s = get_reset_token_serializer()
        # Token expires in 1 hour (3600 seconds)
        token = s.dumps(user.email, salt='password-reset-salt') 
        
        # This URL should point to your frontend password reset page
        # The frontend will then make a PUT/POST request to /auth/reset-password with the token and new password
        reset_url = f"{current_app.config.get('FRONTEND_URL', 'http://localhost:3000')}/reset-password/{token}"
        
        mail_instance = current_app.extensions.get('mail')
        if not mail_instance:
            current_app.logger.error("Flask-Mail is not initialized correctly.")
            return jsonify({"message": "Password reset email could not be sent due to server configuration issue."}), 500

        msg = Message(
            subject="Password Reset Request for Jam3yeti",
            recipients=[user.email],
            body=f"Hello {user.username},\n\nPlease click the following link to reset your password: {reset_url}\n\nIf you did not request a password reset, please ignore this email.\n\nThis link will expire in 1 hour."
        )
        try:
            mail_instance.send(msg)
        except Exception as e:
            current_app.logger.error(f"Failed to send password reset email to {user.email}: {str(e)}")
            return jsonify({"message": "Failed to send password reset email. Please try again later."}), 500

    # Always return a generic success message to prevent email enumeration
    return jsonify({"message": "If an account with that email exists, a password reset link has been sent."}), 200

@user_bp.route("/auth/reset-password/<token>", methods=["POST"])
def reset_password_with_token(token):
    s = get_reset_token_serializer()
    try:
        email = s.loads(token, salt='password-reset-salt', max_age=3600) # 1 hour expiry
    except SignatureExpired:
        return jsonify({"message": "The password reset link has expired."}), 400
    except BadTimeSignature:
        return jsonify({"message": "Invalid password reset link."}), 400
    except Exception:
        return jsonify({"message": "Invalid or malformed password reset link."}), 400

    data = request.get_json()
    new_password = data.get("password")

    if not new_password or not is_strong_password(new_password):
        return jsonify({"message": "Password must be at least 8 characters long and include an uppercase letter, a lowercase letter, a digit, and a special character."}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        # This should ideally not happen if token was valid for an existing email
        return jsonify({"message": "User not found for this reset request."}), 404 

    user.set_password(new_password)
    # Optionally, invalidate all existing JWT tokens for this user here if needed
    try:
        db.session.commit()
        # Send confirmation email
        mail_instance = current_app.extensions.get('mail')
        if mail_instance:
            msg = Message(
                subject="Your Jam3yeti Password Has Been Reset",
                recipients=[user.email],
                body=f"Hello {user.username},\n\nYour password has been successfully reset. If you did not perform this action, please contact support immediately."
            )
            try:
                mail_instance.send(msg)
            except Exception as e:
                current_app.logger.error(f"Failed to send password reset confirmation email to {user.email}: {str(e)}")
        return jsonify({"message": "Password has been reset successfully."}), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error resetting password for user {email}: {str(e)}")
        return jsonify({"message": "Failed to reset password. Please try again."}), 500

@user_bp.route("/users/me", methods=["GET"])
@jwt_required()
def get_current_user_details():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404
    return jsonify({
        "id": user.id, "username": user.username, "email": user.email, "full_name": user.full_name,
        "created_at": user.created_at.isoformat() if user.created_at else None,
        "updated_at": user.updated_at.isoformat() if user.updated_at else None,
        "is_active": user.is_active,
        "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None
    }), 200

@user_bp.route("/users/<int:user_id>", methods=["GET"])
@jwt_required()
def get_user_details_by_id(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404
    return jsonify({
        "id": user.id, "username": user.username, "email": user.email, "full_name": user.full_name,
        "created_at": user.created_at.isoformat() if user.created_at else None,
        "updated_at": user.updated_at.isoformat() if user.updated_at else None,
        "is_active": user.is_active,
        "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None
    }), 200

# TODO: Add routes for updating user profile (PUT /users/me), changing password (POST /auth/change-password)
# These routes will also require @jwt_required() and input validation.

